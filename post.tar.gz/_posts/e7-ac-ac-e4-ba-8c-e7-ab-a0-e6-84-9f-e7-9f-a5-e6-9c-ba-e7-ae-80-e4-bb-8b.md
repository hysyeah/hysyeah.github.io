---
title: 感知机-简介
url: 930.html
id: 930
categories:
  - 机器学习
date: 2018-06-08 00:01:58
tags:
---

定义(感知机) 假设输入空间(特征空间)是\[latex\]\\chi \\in \\mathbf {R}^{n}\[/latex\],输出空间是\[latex\]\\mathcal{Y} =\\{+1,-1\\}\[/latex\].输入\[latex\]x \\in \\chi\[/latex\]表示实例的特征向量，对应于输入空间的点，输出\[latex\]y \\in \\mathcal{Y}\[/latex\]表示实例的类别.由输入空间到输出空间的如下函数 \[latex\]f(x) = sign(w\\cdot x + b) \[/latex\] 称为感知机.其中，w和b为感知机模型参数，\[latex\]w \\in \\mathbf {R}^{n}\[/latex\]叫作权值或权值向量，\[latex\]b \\in \\mathbf{R}\[/latex\]叫作偏置，\[latex\]w \\cdot x\[/latex\]表示w和x的内积。sign是符号函数，即 \[latex\]sign(x)= \\begin{cases} +1,& {x \\geq 0}\\\ -1,& {x \\le 0} \\end{cases} \[/latex\] 感知机是一种线性分类模型，属于判别模型。感知机模型的假设空间是定义在特征空间中的所有线性分类模型或线性分类器，即函数集合\[latex\]\\{f|f(x)=w \\cdot x + b\\}\[/latex\]

* * *

感知机学习策略 定义(数据集的线性可分性) 给定一个数据集 \[latex\]T = \\{(x_{1},y_{1}),(x_{2},y_{2}),\\cdot \\cdot \\cdot,(x_{N},y_{N})\\}\[/latex\],其中，\[latex\]x_{i} \\in \\chi=\\mathcal R^{n}\[/latex\],\[latex\]y_{i} \\in \\chi =\\{+1,-1\\} i=1,2,\\cdot \\cdot \\cdot,N\[/latex\],如果存在某个超平面S \[latex\]w \\cdot x +b = 0\[/latex\] 能够将数据集的正实例点和负实例点完全正确的划分到超平面的 两侧，即对所有\[latex\]y_{i}=+1\[/latex\]的实例i,有\[latex\]w \\cdot x_{i} > 0\[/latex\],对所有\[latex\]y_{i}=-1\[/latex\]的实例i，有\[latex\]w \\cdot x_{i} \\lt 0\[/latex\],则称数据集T为线性可分数据集；否则，称数据集T线性不可分。

* * *

假设训练数据集是线性可分的，感知机学习的目标是求得一个能够将训练集正实例点和负实例点完全正确分开的分离超平面。感知机采用误分类点到超平面S的总距离作为损失函数。 输入空间中任一点到超平面S的距离： ![](http://hysyeah.top/wp-content/uploads/2018/06/plans_dist.png) ||w||是w的L2范数。 ![](http://hysyeah.top/wp-content/uploads/2018/06/perception_loss_fun.png)

* * *

1.统计学习方法-李航