---
title: python魔法变量之__slots__
url: 158.html
id: 158
categories:
  - python
date: 2017-09-08 22:49:34
tags:
---

**slots**变量，用来限制类能添加的属性。由于'score'没有被放到**slots**中，所以不能绑定score属性，所以报错。 使用**slots**要注意，**slots**定义的属性仅对当前类起作用，对继承的子类是不起作用的： 除非在子类中也定义**slots**这样，子类允许定义的属性就是自身的**slots**加上父类的**slots**.

    In [1]: class Fruit(object):
    ...:        __slots__ = ('name', 'age')
    ...:
    
    In [2]: f = Fruit()
    
    In [3]: f.name = 'hys'
    
    In [4]: f.age = 18
    
    In [5]: f.score = 33
    ---------------------------------------------------------------------------
    AttributeError Traceback (most recent call last)
    <ipython-input-5-f65d994e4176> in <module>()
    ----> 1 f.score = 33
    
    AttributeError: 'Fruit' object has no attribute 'score'
    
    In [6]: class Apple(Fruit):
    ...:        pass
    ...:
    
    In [7]: a = Apple()
    
    In [8]: a.name = 'hys'
    
    In [9]: a.score = 44
    
    In [10]: class Bnana(Fruit):
    ...:         __slots__ = ()
    ...:
    
    In [11]: b = Bnana()
    
    In [12]: b.name = 'hys'
    
    In [13]: b.age = 33
    
    In [14]: b.socre = 6
    ---------------------------------------------------------------------------
    AttributeError Traceback (most recent call last)
    <ipython-input-14-140c427ae185> in <module>()
    ----> 1 b.socre = 6
    
    AttributeError: 'Bnana' object has no attribute 'socre'
    
    

当定义了**slots**属性，Python会针对实例采用一种更加紧凑的内部表示。不再让每个实例都创建一个**dict**字典，现在的实例是围绕着一个固定长度的小型数组来构建的，这和一个元组或者列表很相似。在**slots**中列出的属性名会在内部映射到这个数组的索引下。使用**slots**节省下来的内存根据创建实例数量以及保存的属性类型而有所不同。 优点：节省内存 缺点：Python中有许多部分都依赖于传统的基于字典的实现。定义了**slots**属性的类不支持某些特定的功能，比如多重继承。就大部分情况而言，我们应该只针对那些在程序中被当做数据结构而频繁使用的类上采用**slots**。

* * *

参考： 1.[博客](https://www.liaoxuefeng.com/wiki/001374738125095c955c1e6d8bb493182103fac9270762a000/0013868200605560b1bd3c660bf494282ede59fee17e781000") 2.python cookbook