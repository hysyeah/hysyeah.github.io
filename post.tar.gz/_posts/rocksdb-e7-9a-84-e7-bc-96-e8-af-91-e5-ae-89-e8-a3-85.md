---
title: rocksdb的编译安装
url: 1612.html
id: 1612
categories:
  - 未分类
date: 2018-10-14 09:45:29
tags:
---

rocksdb是一个基于level-db开发的高性能本地型键值对数据库。 系统环境：centos 7.6

    git clone https://github.com/gflags/gflags.git
    cd gflags
    git checkout v2.0
    ./configure && make && sudo make install
    
    # export LD_LIBRARY_PATH=/usr/lib
    
    yum install snappy snappy-devel
    yum install zlib zlib-devel
    yum install bzip2 bzip2-devel
    yum install lz4-devel
    
    
    wget https://github.com/facebook/zstd/archive/v1.1.3.tar.gz
    mv v1.1.3.tar.gz zstd-1.1.3.tar.gz
    tar zxvf zstd-1.1.3.tar.gz
    cd zstd-1.1.3
    make && sudo make install
    

    # 将共享库安装在/usr/lib/目录下，头文件在/usr/include/rocksdb
    wget https://codeload.github.com/facebook/rocksdb/tar.gz/v5.14.3
    tar -xf rocksdb-5.14.3.tar.gz
    cd rocksdb-5.14.3
    make install-shared INSTALL_PATH=/usr
    
    # 安装python-rocksdb
    pip3 install python-rocksdb
    
    

测试是否安装好

    import rocksdb
    db = rocksdb.DB("test.db", rocksdb.Options(create_if_missing=True))
    db.put(b"a", b"b")
    print(db.get(b"a"))
    
    # 如果未出错表示rocksdb已安装好
    

* * *

参考： 1.[https://github.com/facebook/rocksdb/blob/master/INSTALL.md](https://github.com/facebook/rocksdb/blob/master/INSTALL.md) 2.[https://python-rocksdb.readthedocs.io/en/latest/installation.html](https://python-rocksdb.readthedocs.io/en/latest/installation.html)