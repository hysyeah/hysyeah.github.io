---
title: '使用docker搭建hadoop,spark集群'
url: 672.html
id: 672
categories:
  - 未分类
date: 2018-02-12 10:20:30
tags:
---

##### 环境：ubuntu 16.04 64位

##### 安装所需文件： Java SDK 1.8, scala-2.11.11,hadoop-2.7.4,spark-2.2.0-bin-hadoop2.7

* * *

1.docker pull ubuntu 2.启动镜像，docker run -idt \[image_id\] /bin/bash 3.进入容器，安装必要的工具

      apt-get install iputils-ping  #ping命令
      apt-get install net-tools     #ifconfig
    

4.将安装包复制到容器内部，[查看容器主机之间文件复制](http://hysyeah.top/2018/02/07/docker%E5%B8%B8%E7%94%A8%E5%91%BD%E4%BB%A42/ "查看容器主机之间文件复制") 5.解压各个安装包，设置环境变量 ~/.bashrc ![image](http://hysyeah.top/wp-content/uploads/2018/02/hadoopenv.png) docker commit -m "xx" -a "xx" spark_base #生成一个新的镜像 6.新建项目，修改各种[配置文件](https://github.com/hys20151008/hadoop-cluster-config "配置文件") 7.项目目录

    # ssh文件夹下面是通过ssh-keygen -t rsa 命令生成的~/.ssh目录下的所有文件（这样不用每次重新启动新的容器后，都要重新配置ssh)
    
    ├── master
    │   ├── hadoop
    │   ├── spark
    │   └── ssh
    ├── slave1
    │   ├── hadoop
    │   ├── spark
    │   └── ssh
    └── slave2
    |    └── ssh
    |__ docker-compose.yml
    
    

8.[创建网络](http://hysyeah.top/2018/02/01/%E5%90%AF%E5%8A%A8docker-hadoop%E9%9B%86%E7%BE%A4%E5%A4%B1%E8%B4%A5/ "创建网络") docker-compose up -d #启动容器，一个namenode,二个datanode 9.进入master容器，/opt/hadoop-2.7.4/sbin/start-all.sh #启动集群 10. 进入master容器，输入jps，有如下进程

    3191 NameNode
    3817 Jps
    3433 ResourceManager
    

进入slave1容器，输入jps，有如下进程

    962 NodeManager
    1235 Jps
    854 DataNode
    

11.输入hdfs dfsadmin -report可查看节点信息 ![image](http://hysyeah.top/wp-content/uploads/2018/02/hdfsreport.png) 12.测试集群是否正常工作。

    vim a.txt                              #创建本地文件
    hdfs dfs -put a.txt /                  #上传到hdfs文件系统
    cd /opt/hadoop-2.7.4/share/hadoop/mapreduce
    hadoop jar hadoop-mapreduce-examples-2.7.4.jar wordcount /a.txt /out  #执行count计算
    hdfs dfs -text /out/part-r-00000                                      #查看执行结果
    若以上都没有出错，说明集群正常
    

* * *

参考： 1.[http://blog.csdn.net/xu470438000/article/details/50512442](http://blog.csdn.net/xu470438000/article/details/50512442)