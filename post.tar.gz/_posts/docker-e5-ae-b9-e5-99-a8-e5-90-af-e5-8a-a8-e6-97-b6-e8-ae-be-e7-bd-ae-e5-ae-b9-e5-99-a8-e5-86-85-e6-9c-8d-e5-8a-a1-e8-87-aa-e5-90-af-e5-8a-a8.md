---
title: docker容器启动时设置容器内服务自启动
url: 707.html
id: 707
categories:
  - 未分类
date: 2018-02-24 14:47:12
tags:
---

1.编写shell脚本，auto_start.sh

    #！/bin/sh
    /etc/init.d/ssh start  #启动服务
    /bin/bash              #一定要加上这句，否则容器会自动退出
    

2.修改docker-compose.yml

    volumes:
      - ./auto_start.sh:/root/auto_start.sh
    command:["/root/auto_start.sh"]
    

3.启动容器，便会自动启动auto_start.sh中的服务。

* * *

可能出现的问题： 1.exec: \\"/root/auto\_start.sh\\": permission denied": unknown'，提示没有权限 解决方法: 修改宿主机上的auto\_start.sh文件权限，chmod a+x auto_start.sh,重新启动服务。