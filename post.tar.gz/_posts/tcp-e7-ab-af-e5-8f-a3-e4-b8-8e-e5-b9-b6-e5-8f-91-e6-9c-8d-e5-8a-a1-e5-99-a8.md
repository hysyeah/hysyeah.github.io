---
title: tcp端口与并发服务器
tags:
  - tcp/ip
url: 1888.html
id: 1888
categories:
  - 未分类
date: 2019-06-12 07:43:31
---

一、端口的作用是什么？ 在一台服务器中可能有多个进程同时使用TCP,UDP这两种协议中的一种，端口就是用来区分这些进程的。 二、套接字对 一个TCP连接的套接字对是一个定义该连接的两个端点的四元组:本地IP地址、本地TCP端口号、外地IP地址、外地TCP端口号。套接字对唯一标识一个网络上的每个TCP连接。 三、并发服务器 并发服务器中主服务器循环通过派生一个子进程来处理每个新的链接。 我们通过如下代码来理解socket如何处理多个请求。

    import socket
    import threading
    
    bind_ip ="0.0.0.0"
    bind_port = 8080
    
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((bind_ip, bind_port))
    
    server.listen(3)
    
    
    def handle_client(client_socket):
        request = client_socket.recv(1024)
        print("[*] Received: %s" % request)
    
        client_socket.close()
    
    
    while True:
        client, addr = server.accept()
        print(f"client is {client}, addr is {addr}")
    
        client_handler = threading.Thread(target=handle_client, args=(client,))
        client_handler.start()
    

1.`python3 server.py`启动服务器，此时服务器的状态如下图，等待客户端的连接。 ![](http://hysyeah.top/wp-content/uploads/2019/06/concurrency_socket_1.png) 我们使用{0.0.0.0:8080, _:_}指出服务川口春奈 的套接字对。服务器在本地端口8080上等待连接请求。外地IP和外地端口号都没有指定，我们称它为监听套接字(listening socket) 2.在同一台主机上启动一个客户端连接服务器. ![](http://hysyeah.top/wp-content/uploads/2019/06/concurrency_socket_2.png) 客户端会随机生成一个端口与服务端进行连接，在进行连接时的状态如下图: ![](http://hysyeah.top/wp-content/uploads/2019/06/concurrency_socket_3.png) 当三次握手后，客户端与服务端建立连接后 ![](http://hysyeah.top/wp-content/uploads/2019/06/concurrency_socket_4.png) 3.我再启动一个客户端 ![](http://hysyeah.top/wp-content/uploads/2019/06/concurrency_socket_5.png) 连接状态如下： ![](http://hysyeah.top/wp-content/uploads/2019/06/concurrency_socket_6.png)

* * *

总结: TCP必须通过查看套接字对的所有4个元素才能确定由哪个端点接收某个到达的分节。如一个分节来自127.0.0.1端口52822,目的地为127.0.0.1端口8080，它就会被传递给子进程2进行处理。

* * *

参考： 1.《UNIX网络编程》