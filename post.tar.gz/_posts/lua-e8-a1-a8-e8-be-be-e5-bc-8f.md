---
title: lua表达式
url: 311.html
id: 311
categories:
  - LUA
date: 2017-10-09 22:28:15
tags:
---

1.关系运算符

    <  >  <=  >= ==  ~=  
    

这些操作符返回结果为false或true.==和~=比较两个值，lua是强类型比较，如果两个值类型不同，Lua认为两者不同。 Lua通过引用比较tables、userdata、functions，只有当两者是同一对象时才相等。

     > a = {x=1,y=0}
     > b = {x=1,y=0}
     > c == a
     false
     > c = a
     > a == c
     true
     > a == b
     false
    

数字、字符串的比较

    > 0 == "0"
    false
    > 2 < 15
    true
    > "2" < "15"  --按字母顺序进行比较
    false
    

2.逻辑运算符

    and  or not
    

逻辑运算符认为false和nil是假，其他为真（true),0也是true。

    a and b -- 如果a为false,则返回a,否则返回b
    a or b  --如果a为true,则返回a,否则返回b
    > print(1 and 2)
    2
    > print(nil and 1)
    nil
    > print(1 or 2)
    1
    > print(false or 1)
    1
    

例：

    x = x or v
    

等价于：

    if not x then
       x = v
    end
    

C语言中的三元运算符

    a ? b:c
    

在Lua中可以这样实现:

    (a and b) or c
    

not 结果只返回false或者true

    > print(not 0)
    false
    

3.连接运算符

    .. --两个点
    

字符串连接，如果操作数为数字，Lua将数字转成字符串

    > print("Hello " .. "World")
    Hello World
    > print(0 .. 1)
    01