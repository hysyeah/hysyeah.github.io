---
title: matplotlib.pyplot相关函数
url: 435.html
id: 435
categories:
  - pyplot
  - python科学计算
date: 2017-11-28 16:05:45
tags:
---

    import matplotlib.pyplot as plt
    
    plt.title(s, *args, **kwargs) #标题
    
    plt.xlabel(s, *args, **kwargs) #x轴标题
    
    plt.ylabel(s,  *args, **kwargs) #y轴标题
    
    plt.autoscale() #自动适应
    
    plt.xlim(0, 100) #设置x轴坐标 范围
    
    plt.legend() #左上角或右上角上的说明
    plt.grid(True,linestyle='-', color='0.75') #网格
    plt.xticks(locs, [label]) #Set locations and labels
    plt.axis([xmin, xmax, ymin, ymax]) #设置x,y轴的最小最大坐标值
    
    matplotlib.pyplot.subplot(*args, **kwargs)
    返回一个子图坐标系
    subplot(nrows, ncols, plot_number)
    subplot(211)
    
    subplots(nrows=1, ncols=1, sharex=False, sharey=False, squeeze=True, subplot_kw=None, gridspec_kw=None, **fig_kw)
    创建个图表和一系列子图
    return
    fig
    ax:坐标对象
    
    
    plt.imshow(X, cmap='Greys') #展示关于X的图像，X可以是矩阵或PIL Image
    plt.matshow()               #将矩阵以图像的形式展示出来