---
title: python之属性继承
url: 1562.html
id: 1562
categories:
  - python
date: 2018-09-03 19:15:58
tags:
---

    class A:
        a = 1
    
    a, b, c = A(), A(),A()
    
    print(a.a, b.a, c.a)
    
    a.a = 2
    A.a = 3
    print(a.a, A.a, c.a)   # 未对实例c.a赋值，则会继承类属性a的值
    
    print(a.__dict__, A.__dict__, c.__dict__)
    
    # output:
    
    (1, 1, 1)
    (2, 3, 3)
    ({'a': 2}, {'a': 3, '__module__': '__main__', '__doc__': None}, {}) # 实例c的__dict__为空