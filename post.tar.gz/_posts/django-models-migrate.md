---
title: django models migrate
url: 623.html
id: 623
categories:
  - Django
  - Python Web
date: 2017-12-17 16:08:45
tags:
---

    修改models.py后，python manage.py makemigrations未发现改变  
    原因是settings.py中INSTALLED_APPS未添加app名称