---
title: shell创建目录
url: 1743.html
id: 1743
categories:
  - 未分类
date: 2019-04-09 07:11:32
tags:
---

在使用shell脚本创建目录的过程中发现一个现象 当解释器为`#!/bin/sh`时，结果如下 ![](http://hysyeah.top/wp-content/uploads/2019/04/Screenshot-from-2019-04-09-07-05-42.png) 当解释器为`!/bin/bash`时，结果如下 ![](http://hysyeah.top/wp-content/uploads/2019/04/tree_right.png) 原因可能是sh解释器不支持{}语法。

    #!/bin/bash
    
    mkdir -p src/{main,test}/{java,resources,scala}
    mkdir lib project target
    
    echo 'name := "myproject"
    version := "1.0"
    scalaVersion := "2.12.0"' > build.sbt