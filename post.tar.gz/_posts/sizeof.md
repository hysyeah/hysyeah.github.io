---
title: sizeof
url: 421.html
id: 421
categories:
  - C语言
date: 2017-11-14 20:15:41
tags:
---

sizeof是C语言的关键字，返回数据类型长度

    32位系统中返回值类型为 unsigned int
    
    64位系统中返回值类型为 long unsigned int
    
    

    #include<stdio>
    
    int main(void){
        printf("char_size=%lu\n", sizeof(char));//32位系统中需改为%u
        printf("unsigned_char=%lu\n", sizeof(unsigned char));
        printf("signed_char=%lu\n", sizeof(signed char));
    
        printf("\n\n");
        printf("int_size=%lu\n", sizeof(int));
        printf("short_int_size=%lu\n", sizeof(short int));
        printf("long_int_size=%lu\n", sizeof(long int));
        printf("unsigned_long_size=%lu\n", sizeof(unsigned long));
        printf("float_size=%lu\n", sizeof(float));
        printf("double_size=%lu\n", sizeof(double));
        printf("long_double_size=%lu\n", sizeof(long double));
        return 0;
    }
    
    

输出

    //32位                                //64位
    char_size=1                           char_size=1
    unsigned_char=1                       unsigned_char=1
    signed_char=1                         signed_char=1
    
    
    int_size=4                            int_size=4
    unsigned_int_size=4                   unsigned_int_size=4
    short_int_size=2                      short_int_size=2
    long_int_size=4                       long_int_size=8
    unsigned_long_size=4                  unsigned_long_size=8
    float_size=4                          float_size=4
    double_size=8                         double_size=8
    long_double_size=12                   long_double_size=16