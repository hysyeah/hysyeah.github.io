---
title: python魔法变量之__all__
url: 56.html
id: 56
categories:
  - python
date: 2017-08-30 07:51:46
tags:
---

如果用户写成

    from sound.effects import *
    

将会发生什么？理想情况下，你是希望到文件系统寻找这个包下的所有的模块，并导入它们。这可能要花费较长的时间，而且可能产生意想不到的副作用，这些作用本应该只有当子模块是显式导入时才会发生。 唯一的解决办法是包的作者为包提供显式的索引。import语句采用以下约定：如果包中的**init**.py代码定义了一个名为**all**的列表，那么在遇到

    from package import *
    

语句时，会把列表中的所有模块导入。 例如，文件sound/effects/**init**.py可以包含以下代码：

    __all__ = ["echo", "surround", "reverse"]
    
    

这意味着

    from sound.effects import *
    

将导入sound包的三个子模块。 如果**all**没有定义，

    from sound.effects import *
    

不会从sound.effects包中导入所有的子模块到当前命名空间，它只保证sound.effects包已经被导入(可能会运行**init**.py中任何初始化 的代码)，然后导入包中定义的任何名称。这包括 由**init**.py定义的任何的名称（以及显式加载的子模块）。还包括这个包中已经由前面的import 语句显式加载的子模块。 例：

    import sound.effects.echo
    
    import sound.effects.surround
    
    from sound.effects import *
    
    

当执行from ... import语句时，echo和surround模块被导入当前命名空间，因为前面已经通过import语句显式加载。 参考：官方文档