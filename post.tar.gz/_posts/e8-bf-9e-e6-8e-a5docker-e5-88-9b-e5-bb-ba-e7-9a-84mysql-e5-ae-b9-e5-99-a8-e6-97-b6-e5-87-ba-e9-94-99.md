---
title: 连接docker创建的mysql容器时出错
url: 913.html
id: 913
categories:
  - 未分类
date: 2018-05-29 18:01:11
tags:
---

连接mysql容器时报错如下 ERROR 2059 (HY000): Authentication plugin 'caching\_sha2\_password' cannot be loaded: /usr/lib/mysql/plugin/caching\_sha2\_password.so: cannot open shared object file: No such file or directory 原因是docker pull下来的是最新的mysql镜像，移除镜像，重新拉取5.7版的镜像即可

    docker pull mysql:5.7