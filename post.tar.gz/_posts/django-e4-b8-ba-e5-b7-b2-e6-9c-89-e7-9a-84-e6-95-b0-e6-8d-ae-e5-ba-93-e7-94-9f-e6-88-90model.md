---
title: Django为已有的数据库生成model
url: 194.html
id: 194
categories:
  - Django
date: 2017-09-15 17:17:09
tags:
---

    python manage.py inspectdb
    

    # 将settings.py中DATABASES中指定的数据库的所表的model导入到models.py中
    python manage.py inspectdb > models.py
    
    

    # 也可以指定数据表
    python manage.py inspectdb xxx xxx >> models.py