---
title: Racket数据类型
url: 332.html
id: 332
categories:
  - Racket
date: 2017-11-04 18:19:09
tags:
---

1.1 Numbers包括小数和虚数

    > 1
    1
    > 1/2
    1/2
    > 1+2i
    1+2i
    > 3.14
    3.14
    

1.2 Booleans,#t表示真，#f表示假 1.3 Byte,值在0-255的整数

    >(byte? 0)
    #t
    > (byte? 256)
    #f
    
    

1.4 Characters,单个字符

    > (integer->char 65)
    #\A
    > (display #\A)
    A
    

1.5 Strings,用双引号包围

    > "Hello,World"
    "Hello,World"
    
    

1.6 Symbols 就原子值，打印的时候以'开始

    > 'a
    'a
    > (symbol? 'a)
    #t
    
    

1.7 Keyword,和symbol类似，但打印的时候以#:开始

    > (string->keyword "apple")
    '#:apple
    
    
    

1.8 Pairs,可以连接两个任意值，cons函数用来构造Pairs

    > (pair? (cons 1 2))
    #t
    

1.9 Lists 列表

    > (list 1 2 3)
    '(1 2 3)
    

2.0 Vector,是固定长度可以存放任意值的列表，支持常量 时间获取元素和更新元素

    > (vector-ref #(name (that tune)) 1)
    '(that tune)
    

2.1 Hash Tables,字典

    >(define ht (make-hash))
    
    >(hash-set! ht "apple" '(red round))
    
    >(hash-ref ht "apple")
    
    '(red round)
    
    

2.2 Boxes,是一个只有一个元素的vertor,打印以#&开始

    > (define b (box "apple"))
    > b
    '#&"apple"
    > (unbox b)
    "apple"
    > (set-box! b '(banana boat))
    > b
    '#&(banana boat)