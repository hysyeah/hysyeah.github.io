---
title: 'apue第一章:UNIX系统概览-笔记'
tags:
  - apue
url: 445.html
id: 445
categories:
  - apue
date: 2017-12-03 11:44:10
---

1.unix架构

###### 狭义上说，操作系统被定义为可以利用,控制硬件资源和为程序提供运行环境。

###### 广义上说，操作系统就是通过内核和其实相关软件使电脑可以被使用和拥有其属性。

![image](http://hysyeah.top/wp-content/uploads/2017/11/QQ图片20171127185444.png)

* * *

2.用户登录

###### 当用户进行登录操作时，系统会从密码文件中查找用户名，通常这个文件为/etc/passwd,后面的操作系统把加密后的密码存放在/etc/shadow中,[/etc/shadow介绍](http://hysyeah.top/2017/11/13/etcshadow%E5%8F%8A%E7%9B%B8%E5%85%B3c%E5%87%BD%E6%95%B0/)。

    # /etc/passwd
    hys:x:1000:1000:hys,,,:/home/hys:/bin/zsh
    

用户名

加密后密码

用户ID

组ID

注释字段

home 目录

shell

hys

x

1000

1000

hys,,,

/home/hys/

/bin/zsh

    # 打印出系统中的所有用户
    cat /etc/passwd | awk -F : '{print $1}'
    

* * *

3.以'/'开头的路径叫**绝对路径**，反之都是**相对路径**。

* * *

4.输入，输出

###### 文件描述符，通常是一个非负数，内核用于标识被特定进程访问的文件。

###### 无论何时运行一个程序，shell都会打开三个描述符:标准输入，标准输出，标准错误。

###### 无缓冲I/O，不使用缓冲的输入/输出，如系统调用:open,read,write,lseek,close。

* * *

5.程序和进程

###### 程序是指存储在磁盘中的可执行文件。

###### 程序的执行实例称为进程，进程ID用于标识进程的唯一非负数。

###### 线程，通常一个进程只有一个线程，多线程可以提高对多核处理器的利用。在同一进程中的所有线程共享相同的地址空间，文件描述符，栈和进程相关属性。

![image](http://hysyeah.top/wp-content/uploads/2017/12/1.png) 图片来源：<<程序员的自我修养>>

* * *

6.用户标识

###### User ID非负数，系统用于标识用户

###### Group ID，组ID，用于用户分组

    # /etc/group
    adm:x:4:syslog,hys
    

组名

口令

组ID

所属组用户(用,隔开)

adm

x

4

syslog,hys

* * *

7.信号

###### 信号的三种处理方式：1.忽略，2.默认动作，3.提供自定义动作

8.时间值

###### Clock time，程序运行所消耗的时间

###### User CPU time,进程获得CPU资源后，在用户态的执行时间

###### System CPU time,进程获得CPU资源后，在内核态的执行时间

* * *

9.系统调用与库函数

系统调用

库函数

数量有限

数量较多

直接调用内核服务

不能直接调用内核服务

精简高效，只提供最底层服务

对用户友好，属于用户层函数

c函数

c函数

不可替换

库函数可替换，而系统调用不可

![image](http://hysyeah.top/wp-content/uploads/2017/12/c-library.png)