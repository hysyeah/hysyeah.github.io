---
title: wordpress隐藏登录入口
url: 96.html
id: 96
categories:
  - 未分类
date: 2017-09-04 21:59:13
tags:
---

在wordpress根目录下打开wp-login.php文件，在

    require( dirname(__FILE__) . '/wp-load.php' );
    
    

后面加上下面

    if($_GET['hehe'] != 'haha'){
    header('Location: http://www.taobao.com/');
    }
    

当别人访问hysyeah.top/wp-login.php时会被重定向到http://www.taobao.com/,只有hysyeah.top/wp-login.php?hehe=haha才能正常打开后台登录界面。

* * *

参考 1.[http://www.luoxiao123.cn/5434.html](http://www.luoxiao123.cn/5434.html)