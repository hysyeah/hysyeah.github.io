---
title: racket string类型
url: 362.html
id: 362
categories:
  - Racket
date: 2017-11-09 23:58:30
tags:
---

    (string-ref str k) → char? ;通过下标获取字符串元素
      str : string?
      k : exact-nonnegative-integer?</pre>
    
    
    
    >(string-ref "hello" 0)
    #\h
    
    

    (make-string k [char]) → string?
      k : exact-nonnegative-integer?
      char : char? = #\nul
    通过给定一个字符串长度，和一个默认填充字符串，返回一个可改变的字符串
    
    
    
    
    
    >(define s (make-string 5 #\z))
    >s
    "zzzzz"
    
    

    (string-set! str k char) → void?
      str : (and/c string? (not/c immutable?))
      k : exact-nonnegative-integer?
      char : char?
    修改可变字符串str的第k个字符串为char</pre>
    
    
    
    >(string-set! s 2 #\&)
    >s
    "zz&zz"
    

    (string<? str1 str2 ...+) → boolean?
      str1 : string?
      str2 : string?
    字符串比较，如果str1<str2 ...+,刚返回#t,
    
    (string<=? str1 str2 ...+) → boolean?
      str1 : string?
      str2 : string?
    (string=? str1 str2 ...+) → boolean?
      str1 : string?
      str2 : string?
    判断str1,str2 ...+是否相等
    (string>? str1 str2 ...+) → boolean?
      str1 : string?
      str2 : string?</pre>
    
    
    
    (string-copy! dest  ;目标字符串  
        dest-start      ;目标字符串起始下标
        src             ;源字符串
        [src-start      ;源字符串起始下标
         src-end]) → void?  ;源字符串结束下标
        dest : (and/c string? (not/c immutable?))  
        dest-start : exact-nonnegative-integer?  
        src : string?  
        src-start : exact-nonnegative-integer? = 0  
        src-end : exact-nonnegative-integer? = (string-length src)
    
    
    >(string-copy! s 0 "hello" 0 5)
    >s
    "hello"
    

    (string-fill! dest char) → void?
      dest : (and/c string? (not/c immutable?))
      char : char?
      填充字符串</pre>
    
    
    >(string-fill! s #\q)
    >s
    "qqqqq"
    

    (string-append str ...) → string?
      str : string?
    返回一个新的拼接的字符串</pre>
    
    
    >(string-append "Apple" "Banana")
    "AppleBanana"
    

    (string-length str) → exact-nonnegative-integer?
      str : string?
      返回字符串长度</pre>
    
    
    >(string-length "Hello")
    5
    

    (substring str start [end]) → string?
      str : string?
      start : exact-nonnegative-integer?
      end : exact-nonnegative-integer? = (string-length str)
      获取子字符串</pre>
    
    
    >(substring "hello" 0 4)
    "hell"
    

    (string->list str) → (listof char?)
      str : string?
      将字符串转换为列表</pre>
    
    
    >(string->list "Apple")
    '(#\A #\p #\p #\l #\e)
    

    (list->string lst) → string?
      lst : (listof char?)
      将列表转换为string</pre>
    
    
    >(list->string (list #\A #\p #\p #\l #\e))
    "Apple"
    

    (build-string n proc) → string?
      n : exact-nonnegative-integer?
      proc : (exact-nonnegative-integer? . ->. char?)
      通过proc以0-n的顺序创建一个长度为n的字符串</pre>
    
    
    >(build-string 5 (lambda (i) (integer->char (+ i 97))))
    "abcde"
    

    (string-ci=? str1 str2 ...+) → boolean?
      str1 : string?
      str2 : string?
      当参数str1,str2 ...+经过函数string-foldcase处理，若str1,str2 ...+相等则返回true
    (string-ci<? str1 str2 ...+) → boolean? 
      str1 : string? 
      str2 : string? 
    (string-ci<=? str1 str2 ...+) → boolean? 
      str1 : string? 
      str2 : string? 
    (string-ci>? str1 str2 ...+) → boolean? 
      str1 : string? 
      str2 : string?</pre>
    
    
    >(string-ci=? "Apple" "apple")
    #t
    

    (string-upcase str) → string?
      str : string?
      将字符串转换为大写
    (string-downcase string) → string?
      string : string?
      将字符串转换为小写
    (string-titlecase string) → string?
      string : string?
      将单词的第一个字母进行大写
    (string-foldcase string) → string?
      string : string?
      将字符串转换为小写，特殊字符存在某种转换</pre>
    
    
    >(string-foldcase "Straße")
    "strasse"
    >(string-downcase "Straße")
    "straße"
    

    (string-join strs    ;以指定分隔符连接字符串
       [sep    
       #:before-first before-first    
       #:before-last before-last    
       #:after-last after-last]) → string?  
      strs : (listof string?)  
      sep : string? = " "  
      before-first : string? = ""  
      before-last : string? = sep  
      after-last : string? = "")
    
    
    >(string-join '("one" "two" "three" "four") ";")
    "one;two;three;four"
    

     (string-split str   ;切分字符串，返回一个列表
        [sep    
         #:trim? trim?    
         #:repeat? repeat?]) → (listof string?)  
        str : string?  
        sep : (or/c string? regexp?) = #px"\\s+"  
        trim? : any/c = #t  
        repeat? : any/c = #f)</pre>
    
    
    >(string-split " foo bar baz \r\n\t")
    '("foo" "bar" "baz")
    

    (string-trim str    ;去掉字符串前后的sep
       [sep    
        #:left? left?    
        #:right? right?    
        #:repeat? repeat?]) → string?  
       str : string?  
       sep : (or/c string? regexp?) = #px"\\s+"  
       left? : any/c = #t  
       right? : any/c = #t  repeat? : any/c = #f</pre>
    
    
    >(string-trim "  foo bar  baz \r\n\t")
    "foo bar  baz"
    

    (non-empty-string? x) → boolean?
      x : any/c
    当x是字符串且不为空时，返回#t，否则返回#f</pre>
    
    
    >(non-empty-string? "")
    #f
    

    (string-contains? s contained) → boolean?
      s : string?
      contained : string?
    判断containde是否存在于s中</pre>
    
    
    >(string-contains? "ab" "a")
    #t
    

    (string-prefix? s prefix) → boolean?
      s : string?
      prefix : string?
      判断是否是开头
    (string-suffix? s suffix) → boolean?
      s : string?
      suffix : string?
      判断是否是结尾</pre>
    
    
    >(string-prefix? "hello" "he")
    #t
    

    >(string-suffix? "hello" "lo")
    #t
    

参考： 1.[官方文档](https://docs.racket-lang.org/reference/strings.html?q=string#%28def._%28%28quote._~23~25kernel%29._string%29%29)