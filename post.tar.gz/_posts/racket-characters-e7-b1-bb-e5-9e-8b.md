---
title: racket Characters类型
url: 1324.html
id: 1324
categories:
  - Racket
date: 2018-07-20 18:19:37
tags:
---

    > (char? #\a)                                            ;判断是否是字符
    #t
    
    > (char->integer #\λ)                                    ;返回字符的整数
    955
    > (char->integer #\A)
    65
    
    > (integer->char 65)                                     ;将整数转换为整数
    #\A
    
    
    > (char=? #\a #\a #\a)                                   ;判断多个字符是否相等
    #t
    
    > (char<? #\A #\a)                                       ;根据(char->integer v)返回的整数值进行比较
    #t
    > (char<? #\A #\λ)
    #t
    
    > (char<=? #\a #\b #\b)
    #t
    
    > (char>? #\a #\A)
    #t
    
    > (char>=? #\a #\A)
    #t
    
    ;生成与Unicode定义的1对1映射一致的字符。如果字符没有大写映射，则char-upcase会生成char
    > (char-upcase #\a)
    #\A
    > (char-upcase #\λ)
    #\Λ
    
    > (char-downcase #\A)
    #\a
    > (char-downcase #\Λ)
    #\λ
    
    ;和char-upcase类似，但对对应于Unicode case-folding mapping
    > (char-foldcase #\A)
    #\a
    > (char-foldcase #\Σ)
    #\σ
    
    > (char-ci<? #\A #\a)
    #f
    > (char-ci<? #\a #\b)
    #t
    > (char-ci<? #\a #\b #\c)
    #t
    
    

* * *

参考： 1.[官方文档](http://docs.racket-lang.org/reference/characters.html#%28def._%28%28quote._~23~25kernel%29._char-upcase%29%29)