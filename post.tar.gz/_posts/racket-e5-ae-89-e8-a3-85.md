---
title: racket安装
url: 253.html
id: 253
categories:
  - Racket
date: 2017-09-25 23:11:40
tags:
---

系统ubuntu16.04，64位 1.[从官网根据系统下载安装包](https://download.racket-lang.org/) 2.安装，如下图 ![image](http://hysyeah.top/wp-content/uploads/2017/09/1.png) 3.添加环境变量 在~/.bashrc添加

    export PATH=&quot;/usr/local/racket/bin:$PATH&quot;
    
    source ~/.bashrc
    
    

4.racket,进入REPL环境