---
title: matplotlib.pyplot添加中文显示
url: 653.html
id: 653
categories:
  - pyplot
date: 2018-01-14 20:56:25
tags:
---

    1.从C:\Windows\Fonts复制微软雅黑字体到/usr/local/lib/python3.5/dist-packages/matplotlib/mpl-data/fonts/ttf
    
    然后将名称修改为
    sudo mv MSYHBD.TTF MSYHBD.ttf
    sudo mv MSYH.TTF MSYH.ttf
    
    2.获取配置文件信息，修改文件
    In [1]: import matplotlib
    
    In [2]: matplotlib.matplotlib_fname()
    Out[2]: '/usr/local/lib/python3.5/dist-packages/matplotlib/mpl-data/matplotlibrc'
    
    font.family         : Microsoft YaHei
    font.sans-serif     : DejaVu Sans, Bitstream Vera Sans, Lucida Grande, Verdana, Geneva, Lucid, Arial, Helvetica, Avant Garde, sans-serif, Microsoft YaHei
    
    3.删除~/.cache/matplotlib下文件fontList.py3k.cache,重启终端。
    
    

![image](http://hysyeah.top/wp-content/uploads/2018/01/matplotlibrc.png)