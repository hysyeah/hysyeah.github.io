---
title: sbt设置国内源
url: 1751.html
id: 1751
categories:
  - Scala
date: 2019-04-09 07:32:16
tags:
---

sbt默认使用的是国外的源，速度太慢，因此改为国内的源。 ![](http://hysyeah.top/wp-content/uploads/2019/04/sbt_source.png) 1.修改下面两个文件，在末尾添加`-Dsbt.override.build.repos=true`

    /usr/share/sbt/conf/sbtconfig.txt
    /usr/share/sbt/conf/sbtopts
    

2.`vim ~/.sbt/repositories`如果不存在则创建

    hys@hys:~$ cat ~/.sbt/repositories 
    [repositories]
      local
      aliyun-nexus: http://maven.aliyun.com/nexus/content/groups/public/
      typesafe: http://repo.typesafe.com/typesafe/ivy-releases/, [organization]/[module]/(scala_[scalaVersion]/)(sbt_[sbtVersion]/)[revision]/[type]s/[artifact](-[classifier]).[ext], bootOnly
    sonatype-oss-releases
    maven-central
    sonatype-oss-snapshots
    

3.生效。

* * *

参考： １.[https://www.jianshu.com/p/a867b2a7c3c8](https://www.jianshu.com/p/a867b2a7c3c8)