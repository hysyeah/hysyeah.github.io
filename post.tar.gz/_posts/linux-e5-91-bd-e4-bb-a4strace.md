---
title: linux命令strace
url: 1713.html
id: 1713
categories:
  - Linux
date: 2019-03-30 22:36:48
tags:
---

`strace`是Linux/Unix下的一款可以追踪系统调用的工具。 1.安装`strace`

    apt-get install strace           # ubuntu
    yum install strace               # centos
    

#### 2.使用示例

![](http://hysyeah.top/wp-content/uploads/2019/03/strace.png)

#### 3.strace -p

    strace -p pid     # 根据进程id,追踪此进程系统调用 
    

##### 查看nginx: worker process进程的系统调用

![](http://hysyeah.top/wp-content/uploads/2019/03/strace_p.png)

#### 4.strace -c

##### 统计时间，调用数，错误

![](http://hysyeah.top/wp-content/uploads/2019/03/strace_c.png)

#### 5.strace -e type=expr

expr = set, file, process, network, signal,ipc, desc,memory ![](http://hysyeah.top/wp-content/uploads/2019/03/strace_type.png)

##### 指定追踪系统调用类型

![](http://hysyeah.top/wp-content/uploads/2019/03/strace_e.png)

#### 6.strace -o out.txt

##### 将输出重定向一 个文件

![](http://hysyeah.top/wp-content/uploads/2019/03/strace_o.png)

#### 7.strace -i

##### 输出系统调用的指针地址

![](http://hysyeah.top/wp-content/uploads/2019/03/strace_i.png)

#### 8.详细参数可通过下面命令查看

    man strace