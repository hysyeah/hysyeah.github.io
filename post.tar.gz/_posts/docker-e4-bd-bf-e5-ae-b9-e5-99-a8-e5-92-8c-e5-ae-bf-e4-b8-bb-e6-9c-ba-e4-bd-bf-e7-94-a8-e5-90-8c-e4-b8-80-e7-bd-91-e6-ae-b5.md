---
title: docker使容器和宿主机使用同一网段
url: 721.html
id: 721
categories:
  - 未分类
date: 2018-03-16 18:19:00
tags:
---

##### 1.通过ifconfig查询物理网卡信息，名称为eno1

![image](http://hysyeah.top/wp-content/uploads/2018/03/maclvan_ifconfig.png)

##### 2.route -n,查询网关为10.68.2.1

![image](http://hysyeah.top/wp-content/uploads/2018/03/maclvan_route.png)

##### 3.使用docker命令创建网络

    docker network create -d macvlan \
    --subnet 10.68.2.0/24 --gateway 10.68.2.1 \
    -o parent=eno1 -o macvlan_mode=bridge macnet
    # parent指定物理网卡名称,
    # 创建的网络名称为macnet
    

##### 4.创建docker-compose.yml文件

    version: "2"
    services:
      ubuntu-master:
        image: ubuntu:16.04
        networks:
           default:
              ipv4_address: 10.68.2.133
        container_name: ubuntu-master
        privileged: true
        tty: true
    networks:
      default:
        external:
          name: macnet
    

##### 5.启动容器，查看IP

![image](http://hysyeah.top/wp-content/uploads/2018/03/maclvan_ip.png)