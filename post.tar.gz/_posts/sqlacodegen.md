---
title: sqlacodegen
url: 1662.html
id: 1662
categories:
  - python
date: 2019-02-17 10:23:49
tags:
---

    Generates SQLAlchemy model code from an existing database.
    
    positional arguments:
      url                SQLAlchemy url to the database
    
    optional arguments:
      -h, --help         show this help message and exit
      --version          print the version number and exit
      --schema SCHEMA    load tables from an alternate schema(指定schema)
      --tables TABLES    tables to process (comma-separated, default: all)
      --noviews          ignore views
      --noindexes        ignore indexes
      --noconstraints    ignore constraints(忽略外键)
      --nojoined         don't autodetect joined table inheritance
      --noinflect        don't try to convert tables names to singular form
      --noclasses        don't generate classes, only tables
      --outfile OUTFILE  file to write output to (default: stdout)
    

例：

    sqlacodegen mysql+pymysql://root:root@127.0.0.1/cloud --noviews --noconstraints --tables host,vpn --outfile out.txt