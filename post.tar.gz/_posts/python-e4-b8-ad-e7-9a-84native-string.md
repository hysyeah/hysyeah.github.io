---
title: python中的native string
url: 749.html
id: 749
categories:
  - requests
date: 2018-03-26 22:37:29
tags:
---

    # 将给定的字符串对象转换为native string
    def to_native_string(string, encoding='ascii'):
        if isinstance(string, builtin_str):
            out = string
        else:
            if is_py2:
                out = string.encode(encoding)
            else:
                out = string.decode(encoding)
    
        return out
    

* * *

1."Native" strings(指那些类型名为str的字符串类型)，用于请求/响应头和元数据。 2."Bytestring"(在python3中类型名为bytes,python2中为str),用于请求/响应中的body。

* * *

参考： 1.[pep3333](https://www.python.org/dev/peps/pep-3333/) 2.[requests源码](https://github.com/requests/requests/blob/v2.8.0/requests/utils.py#L665) 3.[http://hysyeah.top/2017/10/02/python%E7%BC%96%E7%A0%81/](http://hysyeah.top/2017/10/02/python%E7%BC%96%E7%A0%81/)