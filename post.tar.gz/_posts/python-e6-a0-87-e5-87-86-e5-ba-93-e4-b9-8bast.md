---
title: python标准库之ast
url: 759.html
id: 759
categories:
  - python标准库
date: 2018-04-01 12:04:30
tags:
---

##### ast-Abstract Syntax Trees

##### 用于帮助python应用处理抽象语法树

    #　ast.literal_eval()将包含在字符串中的python结构转换为python结构，这些结构包含：strings, bytes, numbers, tuples, lists, dicts, sets, booleans, and None
    In [33]: s = '[1, 2, 3]'
    
    In [34]: lst = ast.literal_eval(s)
    
    In [35]: lst
    Out[35]: [1, 2, 3]
    
    In [39]: s2 = "{'a': 1, 'b': 2}"
    
    In [40]: s2
    Out[40]: "{'a': 1, 'b': 2}"
    
    In [41]: ast.literal_eval(s2)
    Out[41]: {'a': 1, 'b': 2}