---
title: docker常用命令
url: 238.html
id: 238
categories:
  - 未分类
date: 2017-09-25 22:26:03
tags:
---

-docker安装\[通过脚本安装\]

    curl -sSL https://get.daocloud.io/docker | sh
    
    

-常用命令

    sudo apt-get update
    
    sudo systemctl enable docker
    
    sudo systemctl start docker #启动docker
    
    sudo docker push | pull  # 推|拉镜像
    
    sudo docker images #列出本地镜像
    
    sudo docker run -t -i ubuntu:16.04 /bin/bash #-t:让Docker分配一个伪终端，-i:让容器的的标准输入保持打开，-d:后台运行，启动后会返回一个唯一的id
    
    sudo docker tag   #修改镜像的标签
    
    sudo docker save  #保存镜像到本地文件
    
    sudo docker load #从导出的本地文件再加载本地镜像库[sudo docker load --input ubuntu.rar OR sudo docker load < ubuntu.rar]
    
    sudo docker rmi #移除镜像
    
    sudo docker rm  #移除容器
    
    在删除镜像之前要先用docker rm删掉依赖于这个镜像的所有容器。
    
    
    docker run所涉及的操作
    
    - 检查本地是否存在指定的镜像，不存在就从公有仓库下载
    - 利用镜像创建并启动一个容器
    - 分配一个文件系统，并在只读的镜像层外面挂载一层可读写层
    - 从宿主主机配置的网桥接口中桥接一个虚拟接口到容器中去
    - 从地址池配置一个ip地址给容器
    - 执行用户指定的应用程序
    - 执行完毕后容器被终止
    
    sudo  docker ps #查看容器信息，-a:所有容器
    
    docker logs [container ID or NAMES]获取容器的输出信息
    
    docker stop|start|restart [container ID or NAMES] 终止容器|启动容器|重启容器
    sudo docker export #导出本地某个容器，导出容器快照到本地文件 
    sudo docker import #从容器快照文件中再导入为镜像，如cat ubuntu.tar | sudo docker import - test/ubuntu:v1.0
    
    用户既可以使用 docker load 来导入镜像存储文件到本地镜像库，也可以
    使用 docker import 来导入一个容器快照到本地镜像库。这两者的区别在于容
    器快照文件将丢弃所有的历史记录和元数据信息（即仅保存容器当时的快照状
    态），而镜像存储文件将保存完整记录，体积也要大。此外，从容器快照文件导入
    时可以重新指定标签等元数据信息。
    
    sudo docker rm 用来删除一个处于终止状态的容器
    用 docker ps -a 命令可以查看所有已经创建的包括终止状态的容器，如果数量
    太多要一个个删除可能会很麻烦，用 docker rm $(docker ps -a -q) 可以全
    部清理掉。
    *注意：这个命令其实会试图删除所有的包括还在运行中的容器，不过就像上面提过
    的 docker rm 默认并不会删除运行中的容器。
    
    #-m：指定提交说明信息，-a:指定更新的用户信息， 用于创建镜像的容器的ID,最后指定目标镜像的仓库名和tag信息
    sudo docker commit -m "add python3" -a "hys" 425fffab3201 hys/test:v1.0
    

-进入通过参数-d启动的容器 docker attach | nsenter

    - sudo docker attach [container ID or NAMES]
    但是使用 attach 命令有时候并不方便。当多个窗口同时 attach 到同一个容器的
    时候，所有窗口都会同步显示。当某个窗口因命令阻塞时,其他窗口也无法执行操作
    
    

    - nsenter安装
    . sudo wget https://www.kernel.org/pub/linux/utils/util-linux/v2.24/util-linux-2.24.tar.gz
    . tar -xzvf util-linux-2.24.tar.gz
    . cd util-linux-2.24
    . ./configure --without-ncurses
    . make
    . sudo cp nsenter /usr/local/bin
    
    sudo docker inspect --format "{ {.State.Pid }}" [container ID]
    sudo nsenter --target 40621 --mount --uts --ipc --net --pid
    执行出错：nsenter: failed to execute /bin/zsh: No such file or directory
    
    sudo env SHELL="/bin/bash" nsenter --target 40907 --mount --uts --ipc --net --pid
    ok
    
    

-另一种方法，[.bashrc_docker](https://raw.githubusercontent.com/yeasy/docker_practice/master/_local/.bashrc_docker)将里面的内容放到~/.bashrc文件中，

    .bashrc_docker
    
    # Some useful commands to use docker.
    # Author: yeasy@github
    # Created:2014-09-25
    
    alias docker-pid="sudo docker inspect --format '{ {.State.Pid}}'"
    alias docker-ip="sudo docker inspect --format '{ { .NetworkSettings.IPAddress }}'"
    
    #the implementation refs from https://github.com/jpetazzo/nsenter/blob/master/docker-enter
    function docker-enter() {
    #if [ -e $(dirname "$0")/nsenter ]; then
    #Change for centos bash running
    if [ -e $(dirname '$0')/nsenter ]; then
    # with boot2docker, nsenter is not in the PATH but it is in the same folder
    NSENTER=$(dirname "$0")/nsenter
    else
    # if nsenter has already been installed with path notified, here will be clarified
    NSENTER=$(which nsenter)
    #NSENTER=nsenter
    fi
    [ -z "$NSENTER" ]  echo "WARN Cannot find nsenter"  return
    
    if [ -z "$1" ]; then
    echo "Usage: `basename "$0"` CONTAINER [COMMAND [ARG]...]"
    echo ""
    echo "Enters the Docker CONTAINER and executes the specified COMMAND."
    echo "If COMMAND is not specified, runs an interactive shell in CONTAINER."
    else
    PID=$(sudo docker inspect --format "{ {.State.Pid}}" "$1")
    if [ -z "$PID" ]; then
    echo "WARN Cannot find the given container"
    return
    fi
    shift
    
    OPTS="--target $PID --mount --uts --ipc --net --pid"
    
    if [ -z "$1" ]; then
    # No command given.
    # Use su to clear all host environment variables except for TERM,
    # initialize the environment variables HOME, SHELL, USER, LOGNAME, PATH,
    # and start a login shell.
    #sudo $NSENTER "$OPTS" su - root
    sudo $NSENTER --target $PID --mount --uts --ipc --net --pid su - root
    else
    # Use env to clear all host environment variables.
    sudo $NSENTER --target $PID --mount --uts --ipc --net --pid env -i $@
    fi
    fi
    }
    
    

    通过docker-pid可以获取某个容器的PID；而docker_enter可以进入容器 或直接在容器内执行命令
    
    echo $(docker-pid <container>)
    
    docker-enter <container>
    
    

-Dockerfile

    FROM 指令告诉Docker使用哪个镜像作为基础
    MAINTAINER 维护者的信息
    RUN apt-get install
    ADD 复制本地文件到镜像
    EXPOSE 用来向外部开放端口
    
    docker build -t="hys/test:v2.0" . #-t 添加tag,指定新的镜像用户信息。'.'表示Dockerfile所在的路径(当前目录),当然也可以指定具体路径。
    
    sudo apt-get install -y xxx #直接安装
    
    

如：构建django开发环境的镜像

    FROM ubuntu:16.04
    
    MAINTAINER hys <hysyeah.top>
    
    RUN apt-get upadate
    
    RUN apt-get install -y python3-pip
    
    RUN pip3 install django
    
    

* * *

参考：Dockers-从入门到实践