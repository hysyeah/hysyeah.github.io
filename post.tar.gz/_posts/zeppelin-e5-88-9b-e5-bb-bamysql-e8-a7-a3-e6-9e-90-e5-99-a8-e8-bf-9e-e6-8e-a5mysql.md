---
title: 'zeppelin创建mysql解析器,连接mysql'
url: 104.html
id: 104
categories:
  - python科学计算
date: 2017-09-04 23:19:39
tags:
---

[zeppelin环境的配置](http://hysyeah.top/2017/09/04/sparkzeppelin%E7%8E%AF%E5%A2%83%E7%9A%84%E9%85%8D%E7%BD%AE/) 1.创建mysql解析器 ![image](http://hysyeah.top/wp-content/uploads/2017/09/2.png) ![image](http://hysyeah.top/wp-content/uploads/2017/09/3.png) ![image](http://hysyeah.top/wp-content/uploads/2017/09/4.png) ![image](http://hysyeah.top/wp-content/uploads/2017/09/5.png) 2.根据上图填写配置 3.创建Note ![image](http://hysyeah.top/wp-content/uploads/2017/09/6.png) 4.编写sql语句，执行后生成下图 ![image](http://hysyeah.top/wp-content/uploads/2017/09/9.png)

* * *

参考： 1.[https://zeppelin.apache.org/docs/0.7.0/interpreter/jdbc.html](https://zeppelin.apache.org/docs/0.7.0/interpreter/jdbc.html)