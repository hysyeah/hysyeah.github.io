---
title: latex公式
url: 825.html
id: 825
categories:
  - 未分类
date: 2018-05-11 15:35:40
tags:
---

### 常见特殊符号

语法

公式

语法

公式

\\theta

\[latex\]\\theta\[/latex\]

\\alpha

\[latex\]\\alpha\[/latex\]

\\beta

\[latex\]\\beta\[/latex\]

\\gamma

\[latex\]\\gamma\[/latex\]

\\delta

\[latex\]\\delta\[/latex\]

\\epsilon

\[latex\]\\epsilon\[/latex\]

\\zeta

\[latex\]\\zeta\[/latex\]

\\eta

\[latex\]\\eta\[/latex\]

\\rho

\[latex\]\\rho\[/latex\]

\\lambda

\[latex\]\\lambda\[/latex\]

\\mu

\[latex\]\\mu\[/latex\]

\\sigma

\[latex\]\\sigma\[/latex\]

\\phi

\[latex\]\\phi\[/latex\]

\\chi

\[latex\]\\chi\[/latex\]

\\psi

\[latex\]\\psi\[/latex\]

\\omega

\[latex\]\\omega\[/latex\]

\\Theta

\[latex\]\\Theta\[/latex\]

\\Phi

\[latex\]\\Phi\[/latex\]

\\sim

\[latex\]\\sim\[/latex\]

\\mathcal{P}

\[latex\]\\mathcal{P}\[/latex\]

### 上下标

语法

公式

语法

公式

x^2

\[latex\]x^2\[/latex\]

x_2

\[latex\]x_2\[/latex\]

x_{i,j}

\[latex\]x_{i,j}\[/latex\]

x_2^3

\[latex\]x_2^3\[/latex\]

{}\_1^2!X\_3^4

\[latex\]{}\_1^2\\!X\_3^4\[/latex\]

x^{2+2}

\[latex\]x^{2+2}\[/latex\]

\\hat{\\gamma}

\[latex\]\\hat{\\gamma}\[/latex\]

### 导数，积分

语法

公式

语法

公式

x'

\[latex\]x'\[/latex\]

x^\\prime

\[latex\]x^\\prime\[/latex\]

\\dot{x}

\[latex\]\\dot{x}\[/latex\]

\\ddot{x}

\[latex\]\\ddot{y}\[/latex\]

\\vec{c}

\[latex\]\\vec{c}\[/latex\]

\\overleftarrow{a b}

\[latex\]\\overleftarrow{a }\[/latex\]

\\sum_{k=1}^N k^2

\[latex\]\\sum_{k=1}^N k^2\[/latex\]

\\prod_{i=1}^N x_i

\[latex\]\\prod_{i=1}^N x_i\[/latex\]

\\lim_{n \\to \\infty}x_n

\[latex\]\\lim_{n \\to \\infty}x_n\[/latex\]

\\int_{-N}^{N} e^x\\, dx

\[latex\]\\int_{-N}^{N} e^x\\, dx\[/latex\]

### 分数

语法

公式

语法

公式

\\frac{1}{2}

\[latex\]\\frac{1}{2}\[/latex\]

### 其它

![image](http://hysyeah.top/wp-content/uploads/2018/05/latex.png)