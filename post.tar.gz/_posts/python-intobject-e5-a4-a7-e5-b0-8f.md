---
title: python intobject大小
url: 574.html
id: 574
categories:
  - python源码
date: 2017-12-09 21:52:23
tags:
---

    # 64位系统
    #python3                                        python2
    
    In [4]: sys.getsizeof(1)                       In [4]: sys.getsizeof(1)
    Out[4]: 28                                     Out[4]: 24
    
    In [6]: sys.getsizeof(0)                       In [6]: sys.getsizeof(0)
    Out[6]: 24                                     Out[6]: 24
    

在python2 int对象为24个字节,

    #define PyObject_HEAD                   \
        Py_ssize_t ob_refcnt;               \
        struct _typeobject *ob_type;
    
    typedef struct {
        PyObject_HEAD
        long ob_ival;
    } PyIntObject;
    

* * *

python3中已不区分int,long对象，而是将python2中的long对象改名为int对象

    typedef unsigned short digit;
    struct _longobject {
        PyObject_VAR_HEAD
        digit ob_digit[1];
    };
    

python3中sys.getsizeof(0) == 24

     /*zero is represented by ob_size == 0.当int值为0时，ob_size=0，所以不会分配  
     ob_digit[1],所以大小为24Bytes.*/
    

* * *

参考：python源码