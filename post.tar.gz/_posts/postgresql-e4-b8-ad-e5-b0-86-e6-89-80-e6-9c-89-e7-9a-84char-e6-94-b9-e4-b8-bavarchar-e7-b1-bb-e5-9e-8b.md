---
title: postgresql中将所有的char改为varchar类型
tags:
  - postgresql
url: 1842.html
id: 1842
categories:
  - 数据库
date: 2019-05-26 08:57:05
---

在将`Postgresql`数据转换为`Neo4j`的过程中，`char`类型的字段的在转换成`Neo4j`的属性后会带有空格。比如`char(10)`字段的数据为`hello`在`Neo4j`属性中则会带有空格，虽然可以在查询的时候加上trim函数，但这样对于原来的查询代码改动太大。所以决定从源头将这个问题解决。 假如有一个字段为`char(10)`如果插入的数据长度未达到10,关系型数据库默认在后面添加空格，所以将`char`类型改为`varchar`可以解决这个问题。 在`char`类型改为`varchar`的过程中，会默认把`char`类型中的空格给去掉。 在`postgresql`中有一个表`information_schema.columns`记录了所有字段的信息，所以可以从这个表中提取信息进行`char`到`varchar`的转换。

    # 这个语句会生成将char改为varchar的sql语句
    SELECT CONCAT('alter table ', table_schema, '.', table_name, ' alter column ', column_name, ' type ', 'varchar ', '(',character_maxinum_length,');') from information_schema.columns where table_catalog='ptl' and date_type='character';
    

`information_schema.columns`中的常用字段。


|  字段 | 描述  |
| ------------ | ------------ | 
| table_catalog  | 数据库名  | 
| table_schema|数据库的schema|
| table_name|表名|
| column_name|字段名|
| data_type|数据类型|
|character_maximum_length|如果类型为character或bit string type,则为可存储最大字符数|

* * *

参考： 1.[information_schema.columns](https://www.postgresql.org/docs/10/infoschema-columns.html)
