---
title: scipy entropy求熵
url: 903.html
id: 903
categories:
  - python科学计算
date: 2018-05-23 17:23:55
tags:
---

熵(entropy)是表示随机变量不确定性的度量,熵越大,随机变量的不确定性就越大。 设X是一个取有限个值的离散随机变量，其概率分布为 \[latex\]P(X=x_{i}) = p_{i}, i=1,2,\\cdot \\cdot \\cdot,n\[/latex\] 则随机变量X的熵定义为 \[latex\]H(X) = -\\sum_{i=1}^n p_{i}\\log {p_{i}}\[/latex\] 对数以2或e为底

    scipy.stats.entropy(pk, qk=None,base=None)
    计算给定概率值的分布的熵
    

    In [213]: from scipy import stats
    
    In [215]: stats.entropy([9/15,6/15],base=2)
    Out[215]: 0.9709505944546688
    
    

* * *

参考： 1.[scipy文档](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.entropy.html) 2.统计学习方法