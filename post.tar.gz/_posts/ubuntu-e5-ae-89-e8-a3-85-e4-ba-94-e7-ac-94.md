---
title: ubuntu安装五笔
url: 235.html
id: 235
categories:
  - Linux
date: 2017-09-22 17:52:36
tags:
---

    1.sudo apt-get install ibus-table-wubi
    
    2.reboot
    
    3.Text Entry添加输入法