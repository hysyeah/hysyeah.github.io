---
title: docker常用命令2
url: 678.html
id: 678
categories:
  - 未分类
date: 2018-02-07 17:03:27
tags:
---

    # 容器和主机之间的文件复制
    1.从主机复制到容器 sudo docker cp host_path containerid:container_path
    2.从容器复制到主机 sudo docker cp containerid:container_path host_path
    
    

    # 免sudo
    sudo groupadd docker 
    sudo usermod -aG docker $USER
    sudo service docker restart
    sudo chmod a+rw /var/run/docker.sock
    

    ➜  ~ docker images
    REPOSITORY                TAG                 IMAGE ID            CREATED             SIZE
    hyspark                   latest              652a7a9d9fbe        12 days ago         1.66GB
    d.hysyeah.top:5000/busybox   latest              f9b6f7f7b9d3        3 weeks ago         1.14MB
    mysql                     latest              f008d8ff927d        3 weeks ago         409MB
    
    docker save -o mysql.tar mysql  #将镜像导出为mysql.tar文件
    docker load -i mysql.tar        #导入镜像