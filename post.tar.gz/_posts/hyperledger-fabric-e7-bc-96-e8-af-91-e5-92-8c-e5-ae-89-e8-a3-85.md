---
title: Hyperledger Fabric编译和安装
url: 1535.html
id: 1535
categories:
  - 区块链
date: 2018-08-22 23:22:37
tags:
---

#### 环境：ubuntu 16.04 64位

1.依次安装`go 1.9.x`,`docker`,`docker-compose` ![](http://hysyeah.top/wp-content/uploads/2018/08/fabric-req.png) 2.

    mkdir -p $GOPATH/src/github.com/hyperledger
    cd $GOPATH/src/github.com/hyperledger
    git clone http://gerrit.hyperledger.org/r/fabric
    cd fabric
    git checkout release-1.0  # release-1.0才支持go 1.9.x
    

3.安装依赖软件

    go get github.com/golang/protobuf/protoc-gen-go
    mkdir -p $GOPATH/src/github.com/hyperledger/fabric/build/docker/gotools/bin
    # go get之后编译好的文件会放到$GOBIN对应的目录中，如果没有设置$GOBIN的值，生成的文件将默认存放到$GOPATH/bin下面
    cp protoc-gen-go $GOPATH/src/github.com/hyperledger/fabric/build/docker/gotools/bin
    
    

4.编译

    cd $GOPATH/src/github.com/hyperledger/fabric
    make release
    
    make docker //生成docker镜像文件
    

5.编译成功后会在`$GOPATH/src/github.com/hyperledger/fabric/release/linux-amd64/bin`生成如下可执行文件。 ![](http://hysyeah.top/wp-content/uploads/2018/08/fabric-exe.png) 6.make docker 经过漫长的等待后 ![](http://hysyeah.top/wp-content/uploads/2018/08/%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_20180823091621.png) mysql镜像除外

* * *

遇到的问题： 1.执行make release时报如下错误

    gotools.mk:22: *** target pattern contains no '%'.  Stop
    

原因是我的$GOPATH设置了多个路径，改成一个路径之后错误消失。

    export GOPATH="/home/hys/mycode/go:/home/hys/mycode/go/gopl:/home/hys/mycode/go/block"
    ==> export GOPATH="/home/hys/mycode/go/block"
    

2.`golang.org/x`不能访问的问题 [解决方法](http://hysyeah.top/2018/08/22/go-get-golang-orgx-%E5%8C%85%E5%A4%B1%E8%B4%A5%E8%A7%A3%E5%86%B3%E6%96%B9%E6%B3%95/)