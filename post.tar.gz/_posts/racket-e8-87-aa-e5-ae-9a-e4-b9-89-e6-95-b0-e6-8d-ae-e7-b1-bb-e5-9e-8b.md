---
title: racket自定义数据类型
url: 350.html
id: 350
categories:
  - Racket
date: 2017-11-08 23:19:43
tags:
---

racket的自定义数据类型可以 看作C语言的结构体

    >(struct posn (x y)) ;定义个结构体，成员为x,y,默认是不透明结构体
    
    >(define p1 (posn 1 2));定义了p1变量
    
    > (define p2 (struct-copy posn p1 [x 3]));拷贝posn p1 将p1.x修改为3,并将这个变量赋值给p2
    > (list (posn-x p2) (posn-y p2));p2.x=3
    '(3 2)
    > (list (posn-x p1) (posn-x p2));而p1.x=1,使用struct-copy并不会改变p1.x的值
    '(1 3)
    
    

    >(struct posn (x y))
    >(struct 3d-posn posn (z)); 这两行相当于如下C语言：
    
    struct posn {
    
    int x;
    
    int y;
    
    }
    
    struct 3d-posn {
    
    struct posn;
    
    int z;
    
    }
    
    >(define p (3d-posn 1 2 3))
    
    > (3d-posn-z p)
    
    3
    
    ;3d-posn并不包含x,y变量直接访问报错
    > (3-posn-x p)
    . . 3-posn-x: undefined;
    cannot reference an identifier before its definition
    可以这样访问
    > (posn-x p)
    1
    
    

透明结构体，会显示成员变量的值，结构体默认是不透明的

    > (struct posn (x y)
    #:transparent)
    > (posn 1 2)
    (posn 1 2)
    
    结构体的比较
    > (struct posn(x y))
    > (struct tr (x y) #:transparent)
    > (equal? (tr 1 2) (tr 1 2))
    #t
    > (struct op (x y))
    > (equal? (op 1 2) (op 1 2));要比较不透明结构体，可通过#:methods,gen:equal+hash实现三种方法
    #f
    

未完

* * *

参考： 1.[官方文档](https://docs.racket-lang.org/guide/define-struct.html#%28part._.Simple_.Structure_.Types__struct%29)