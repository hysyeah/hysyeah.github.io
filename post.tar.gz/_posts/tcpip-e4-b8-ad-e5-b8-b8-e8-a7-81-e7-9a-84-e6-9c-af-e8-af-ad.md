---
title: tcp/ip中常见的术语
tags:
  - tcp/ip
url: 1912.html
id: 1912
categories:
  - 未分类
date: 2019-06-12 21:54:05
---

    最大分节大小--MSS--maximum segment size
    最大传输单元--MTU--maximum transmission unit  # MSS通常被设置为MTU送去IP和TCP首部的固定长度，IPv4和TCP的首部都是20字节
    协议数据单元--PDU--protocol data unit # 网络各层对等实体间交换的单位信息
    最长分节生命期--MSL--maximum segment lifetime
    监听套接字--listening socket
    已连接套接字--connected socket
    局域网--local area networks(LANs)
    广域网--wide area networks(WANs)
    
    
    
    

未完