---
title: 修改.zshrc文件报badassiment错误
url: 100.html
id: 100
categories:
  - Linux
date: 2017-09-04 22:14:00
tags:
---

修改~/.zshrc文件添加下如下

    export PATH="/usr/local/bin:$PATH"
    

source ~/.zshrc报badassiment错误 原因：=号之间不能有空格