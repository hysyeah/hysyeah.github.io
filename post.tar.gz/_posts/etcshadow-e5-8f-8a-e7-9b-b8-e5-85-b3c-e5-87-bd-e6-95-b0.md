---
title: /etc/shadow及相关c函数
url: 412.html
id: 412
categories:
  - C语言
  - Linux
date: 2017-11-13 23:18:28
tags:
---

/etc/shadow包含系统用户的密码信息，普通用户不能查看此文件 每行分为9个片段，通过冒号':'分隔 hys:$6$q1Jaurz4$8hPn.i0F6k7xPeLNcKDGdKZODMx7uTnHjAXjgvND2dRrz7jk16O.DbI15qe.G9SqSbFO.O0PMsW.yHv1X2/z60:17421:0:99999:7::: 用户名： 加密后的密码(单向散列)： 最后修改密码的时间(为距1970.1.1的天数)： 密码最小存活时间(指用户还有多少天可以修改密码，空或0表示没有密码最小存活时间): 最大密码存活时间(超过这个时间，用户需修改密码，如果这个值小于密码最小存活时间，则用户不能修改密码)： 密码过期前多少天提醒： 密码超过最大存活时间后还能进行登录的时间： 用户过期时间： 保留域

    struct spwd {
        char *sp_namp; /* Login name */
        char *sp_pwdp; /* Encrypted password */
        long sp_lstchg; /* Date of last change(measured in days since 1970-01-01 00:00:00 +0000 (UTC)) */
        long sp_min; /* Min # of days between changes */
        long sp_max; /* Max # of days between changes */
        long sp_warn; /* # of days before password expires to warn user to change it */
        long sp_inact; /* # of days after password expires
        until account is disabled */
        long sp_expire; /* Date when account expires(measured in days since 1970-01-01 00:00:00 +0000 (UTC)) */
        unsigned long sp_flag; /* Reserved */
    };
    

    struct spwd *getspnam(const char *name);//通过用户名获取指向struct spwd结构体的指针
    struct spwd *getspent(void);//获取/etc/shadow文件中的信息，返回struct spwd结构体指针
    void setspent(void);//初始化输入流
    void endspent(void);//释放资源
    

例：

    #include <stdio.h>
    #include <shadow.h>
    #include <unistd.h>
    int main(){
    struct spwd *p,*ptr;
    p = getspnam(usbmux);
    if(p == NULL){
        printf("error");
    }
    printf("%s\n", p->sp_namp);
    printf("%s\n", p->sp_pwdp);
    printf("%ld\n", p->sp_lstchg);
    printf("%ld\n", p->sp_min);
    printf("%ld\n", p->sp_max);
    printf("%ld\n", p->sp_warn);
    printf("%ld\n", p->sp_inact);
    printf("%ld\n", p->sp_expire);
    printf("%lu\n", p->sp_flag);
    setspent();
    while((ptr = getspent())!=NULL){
        printf("%s\n", ptr->sp_namp);
    }
    endspent();
    return 0;
    }
    
    

参考： 1.[http://manpages.ubuntu.com/manpages/precise/man5/shadow.5.html](http://manpages.ubuntu.com/manpages/precise/man5/shadow.5.html) 2.[https://linux.die.net/man/3/getspnam](https://linux.die.net/man/3/getspnam)