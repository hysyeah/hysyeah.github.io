---
title: python之dict与set
url: 1554.html
id: 1554
categories:
  - python
date: 2018-09-01 17:04:58
tags:
---

    In [5]: def f(a,*args,**kwargs):
                print(a)
                print(args)
                print(kwargs)
    
    In [6]: keys =[1, 2, 3]
    In [7]: kwargs = {'a','b'}
    
    In [8]: f('b',*keys,**kwargs)
    ---------------------------------------------------------------------------
    TypeError                                 Traceback (most recent call last)
    <ipython-input-8-5ffd5def4f0f> in <module>()
    ----> 1 f('b',*keys,**kwargs)
    
    TypeError: f() argument after ** must be a mapping, not set
    
    # 这里报错，这里传入的参数必须是字典，而不能是集合，当定义一个字典时，若只有键没有值，那这是一个集合，而不是字典，这应该看作两种完全不一样的数据
    
    
    
    In [9]: k = {'a':'b','c':'d'}
    
    In [10]: f('b',*keys,**k) # *表示可选参数列表，**表示可选参数字典
    ---------------------------------------------------------------------------
    TypeError                                 Traceback (most recent call last)
    <ipython-input-10-8147c79d6830> in <module>()
    ----> 1 f('b',*keys,**k)
    
    TypeError: f() got multiple values for argument 'a'
    
    # 若k中有把'a'作为键的键值对，则会报错
    
    In [13]: f('a',*keys,{'b':'c'}) # 没加**会把{'a':'c'}当作可参数列表中的一部分
    a
    (1, 2, 3, {'b': 'c'})
    {}
    
    In [14]: f('a',*keys,**{'b':'c'})
    a
    (1, 2, 3)
    {'b': 'c'}