---
title: python阶乘
url: 267.html
id: 267
categories:
  - python
date: 2017-09-27 06:51:16
tags:
---

    fact = lambda n:1 if n == 0 else n * fact(n-1)
    
    
    >>> fact(6)
    720
    >>> reduce(lambda x,y:x*y, range(1, 7))
    720