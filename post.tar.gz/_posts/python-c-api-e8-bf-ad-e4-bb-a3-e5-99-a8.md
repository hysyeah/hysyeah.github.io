---
title: python C API 迭代器
url: 554.html
id: 554
categories:
  - python源码
date: 2017-12-02 23:39:08
tags:
---

    #include <stdio.h>
    #include "python3.5m/Python.h"
    int main(int argc, char* argv[]){
        long v;
        Py_Initialize();
        PyObject *t, *item;
        t = PyList_New(3);
        PyList_SetItem(t, 0, PyLong_FromLong(1L));
        PyList_SetItem(t, 1, PyLong_FromLong(2L));
        PyList_SetItem(t, 2, PyLong_FromLong(3L));
        PyObject *iterator = PyObject_GetIter(t);
        if (iterator == NULL){
            printf("error\n");
        }
        while (item = PyIter_Next(iterator)){
           v = PyLong_AsLong(item);
           printf("%ld\n", v);
           Py_DECREF(item);
        }
        Py_DECREF(iterator);
        Py_Finalize();
        return 0;
    }
    
    output:
    1
    2
    3
    

* * *

    /*返回迭代器对象*/
    PyObject* PyObject_GetIter(PyObject *o)
    
    /*获取迭代器o的下 一个值*/
    PyObject* PyIter_Next(PyObject *o)
    
    /*将python对象转换为c long*/
    long PyLong_AsLong(PyObject *pylong)