---
title: 'apue第一章:UNIX系统概览-笔记-函数'
tags:
  - apue
url: 566.html
id: 566
categories:
  - apue
date: 2017-12-03 21:37:42
---

    opendir, fdopendidr ---打开目录
    
    #include <sys/types.h>
    #include <dirent.h>
    
    DIR *opendir(const char *name);
    DIR *fdopendir(int fd);
    struct dirent *readdir(DIR *dirp);
    
    struct __dirstream   
       {   
        void *__fd;    
        char *__data;    
        int __entry_data;    
        char *__ptr;    
        int __entry_ptr;    
        size_t __allocation;    
        size_t __size;    
        __libc_lock_define (, __lock)    
       };   
    
    typedef struct __dirstream DIR;  
    
    struct dirent {
         ino_t          d_ino;       /* inode number */
         off_t          d_off;       /* not an offset; see NOTES */
         unsigned short d_reclen;    /* length of this record */
         unsigned char  d_type;      /* type of file; not supported by all filesystem types */
         char           d_name[256]; /* filename */
    };
    
    

* * *

[read](http://man7.org/linux/man-pages/man2/read.2.html) [write](http://man7.org/linux/man-pages/man2/write.2.html)

    #include <unistd.h>
    /*从文件描述符fd中读取count字节到buf中*/
    ssize_t read(int fd, void *buf, size_t count);
    ssize_t write(int fd, const void *buf, size_t count);
    

* * *

    #include <sys/types.h>
    #include <unistd.h>
    
    /*返回进程ID*/
    pid_t getpid(void);
    /*返回进程的父亲进程ID*/
    pid_t getppid(void);
    
    

* * *

[fork](http://man7.org/linux/man-pages/man2/fork.2.html) [execlp](http://man7.org/linux/man-pages/man3/execlp.3.html)

    #include <sys/types.h>
    #include <unistd.h>
    
    pid_t fork(void);
    

* * *

    #include <string.h>
    /*返回指向错误信息字符串的指针*/
    char *strerror(int errnum);
    
    #include <stdio.h>
    /*根据errno的值返回错误信息*/
    void perror(const char *msg);
    

* * *

[getuid](http://man7.org/linux/man-pages/man3/getuid.3p.html) [getgid](http://man7.org/linux/man-pages/man3/getgid.3p.html)

    #include <unistd.h>
    uid_t getuid(void);
    gid_t getgid(void);
    

* * *

[waitpid](http://man7.org/linux/man-pages/man3/waitpid.3p.html)

    #include <sys/wait.h>
    pid_t waitpid(pid_t pid, int *stat_loc, int options);