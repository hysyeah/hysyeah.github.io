---
title: 'sbt简介,scala项目hello,world'
url: 1761.html
id: 1761
categories:
  - Scala
date: 2019-04-09 08:24:03
tags:
---

sbt(Simple Build Tool)是官方推荐的Scala项目构建工具,为你的项目提供编译，运行，测试等各种功能。 １.sbt安装 - 依赖jdk8,如没安装，需要先安装jdk8

    echo "deb https://dl.bintray.com/sbt/debian /" | sudo tee -a /etc/apt/sources.list.d/sbt.list
    sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 2EE0EA64E40A89B84B2DF73499E82A75642AC823
    sudo apt-get update
    sudo apt-get install sbt
    

2.启动sbt,第一次启动需要下载一些包速度会比较慢,更换源请参考[更换国内源](http://hysyeah.top/2019/04/09/sbt%e8%ae%be%e7%bd%ae%e5%9b%bd%e5%86%85%e6%ba%90/) 3.新建一个简单的项目，结构如下,[创建目录脚本](http://hysyeah.top/2019/04/09/shell%e5%88%9b%e5%bb%ba%e7%9b%ae%e5%bd%95/) ![](http://hysyeah.top/wp-content/uploads/2019/04/tree_right.png) ４.在目录`src/main/scala`下，新建一个文件`hello.scala`

    hys@hys:~/code/scala/helloscala/src/main/scala$ cat hello.scala 
    package foo.bar.baz
    
    object Main extends App {
      println("Hello, Scala")
    }
    

5.编译，运行 ![](http://hysyeah.top/wp-content/uploads/2019/04/sbt_hello.png) 6.sbt命令

![](http://hysyeah.top/wp-content/uploads/2019/04/sbt_command.jpg)
------------------------------------------------------------------

参考： １.[https://www.scala-sbt.org/1.x/docs/Installing-sbt-on-Linux.html](https://www.scala-sbt.org/1.x/docs/Installing-sbt-on-Linux.html) 2.scala编程实战