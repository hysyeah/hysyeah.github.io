---
title: 记wordpress一次坑爹的问题
url: 1978.html
id: 1978
categories:
  - 未分类
date: 2019-06-13 23:52:02
tags:
---

今天晚上发再更新文章时总是提醒`/wp-admin/post.php`,但 查看服务器发现文件存在，最近也没有安装插件。 多方尝试最后将下图红框中的数据删除，点击保存，问题解决。 ![](http://hysyeah.top/wp-content/uploads/2019/06/15604410141.png)