---
title: 工厂模式(Factory Pattern)-创建型
url: 1365.html
id: 1365
categories:
  - 设计模式
date: 2018-09-25 16:52:33
tags:
---

#### 简单工厂设计模式：这允许接口创建对象而不暴露对象创建逻辑

当客户端调用create_type()方法时，工厂会根据type参数的不同，返回Product1或者Product2。 ![](http://hysyeah.top/wp-content/uploads/2018/08/simple-factory-pattern.png)

    from abc import ABCMeta, abstractmethod
    class Animal(metaclass = ABCMeta):
        @abstractmethod
        def do_say(self):
            pass
    
    class Dog(Animal):
        def do_say(self):
            print("Bhow Bhow!!")
    
    class Cat(Animal):
        def do_say(self):
            print("Meow Meow!!")
    
    class ForestFactory:
        def make_sound(self, obj_type):
            return eval(obj_type)().do_say() #根据类型直接调用不同的方法
    
    if __name__ == '__main__':
        ff = ForestFactory()
        ff.make_sound('Cat')
    
    [out]:Meow Meos!!                   # 根据不同的参数返回不同的对象，打印不同的信息
    

* * *

#### 工厂设计模式

提供接口创建对象，但是推迟对子类决定使用哪个类产生对象。定义了一个创建对象的接口，但不是工厂负责创建对象，而是将责任推迟到决定要实例化的类的子类。 ![](http://hysyeah.top/wp-content/uploads/2018/08/factory-method-pattern.png)

    from abc import ABCMeta, abstractmethod
    class Section(metaclass=ABCMeta):
        @abstractmethod
        def describe(self):
            pass
    
    
    class PersonalSection(Section):
        def describe(self):
            print("Personal Section")
    
    
    class AlbumSection(Section):
        def describe(self):
            print("Album Section")
    
    
    class PatentSection(Section):
        def describe(self):
            print("Patent Section")
    
    
    class PublicationSection(Section):
        def describe(self):
            print("Publication Section")
    
    
    class Profile(metaclass=ABCMeta):
        def __init__(self):
            self.sections = []
            self.createProfile()
        @abstractmethod
        def createProfile(self):
            pass
        def getSections(self):
            return self.sections
        def addSections(self, section):
            self.sections.append(section)
    
    
    class linkedin(Profile):
        def createProfile(self):
            self.addSections(PersonalSection())
            self.addSections(PatentSection())
            self.addSections(PublicationSection())
    
    
    class facebook(Profile):
        def createProfile(self):
            self.addSections(PersonalSection())
            self.addSections(AlbumSection())
    
    
    if __name__ == '__main__':
        profile_type = 'linkedin'
        profile = eval(profile_type)()
        print("Creating profile..", type(profile).__name__)
        print("Profile has sections --", profile.getSections())
    

* * *

#### 抽象工厂设计模式

抽象工厂是创建相关对象而不指定/公开其类的接口。该模式提供另一个工厂的对象，该工厂在内部创建其他对象。抽象工厂模式的主要目标是提供一个接口来创建相关对象的族，而无需指定具体类。 ![](http://hysyeah.top/wp-content/uploads/2018/08/abstract-factory-pattern.png)

    from abc import ABCMeta, abstractmethod
    
    class PizzaFactory(metaclass=ABCMeta):
        @abstractmethod
        def createVegPizza(self):
            pass
    
        @abstractmethod
        def createNonVegPizza(self):
            pass
    
    
    class IndianPizzaFactory(PizzaFactory):
        def createVegPizza(self):
            return DeluxVeggiePizza()
        def createNonVegPizza(self):
            return ChickenPizza()
    
    
    class USPizzaFactory(PizzaFactory):
        def createVegPizza(self):
            return MexicanVegPizza()
        def createNonVegPizza(self):
            return HamPizza()
    
    
    class VegPizza(metaclass=ABCMeta):
        @abstractmethod
        def prepare(self, VegPizza):
            pass
    
    class NonVegPizza(metaclass=ABCMeta):
        @abstractmethod
        def serve(self, NonVegPizza):
            pass
    
    
    class DeluxVeggiePizza(VegPizza):
        def prepare(self):
            print("Prepare ", type(self).__name__)
    
    
    class ChickenPizza(NonVegPizza):
        def serve(self, VegPizza):
            print(type(self).__name__, " is served with Chicken on ", type(VegPizza).__name__)
    
    
    class MexicanVegPizza(VegPizza):
        def prepare(self):
            print("Prepare ", type(self).__name__)
    
    
    class HamPizza(NonVegPizza):
        def serve(self, VegPizza):
            print(type(self).__name__, " is served with Ham on ", type(VegPizza).__name__)
    
    
    
    class PizzaStore:
        def __init__(self):
            pass
        def makePizzas(self):
            for factory in [IndianPizzaFactory(), USPizzaFactory()]:
                self.factory = factory
                self.NonVegPizza = self.factory.createNonVegPizza()
                self.VegPizza = self.factory.createVegPizza()
                self.VegPizza.prepare()
                self.NonVegPizza.serve(self.VegPizza)
    
    
    
    pizza = PizzaStore()
    pizza.makePizzas()
    

* * *

工厂方法和抽象工厂方法的区别 在面象对象编程中，工厂意味着负责创建其它类型对象的类 工厂方法模式：这允许接口创建对象，但是推迟对子类决定使用哪个类产生对象 抽象工厂模式：抽象工厂是创建相关对象而不指定/公开其类的接口。该模式提供另一个工厂的对象，该工厂在内部创建其他对象 工厂模式的优点： 1.松散耦合，其中对象创建可以独立于类实现 2.客户端不必知道具体实现，只需要知道接口，方法和传递参数就可以了 3.可以轻松地将另一个类添加到工厂以创建另一种类型的对象,客户端不用修改代码 4.可以重用已存在的对象