---
title: django添加自定义过滤器
url: 147.html
id: 147
categories:
  - Django
date: 2017-09-08 15:27:32
tags:
---

1.在app目录下与models.py同级目录下新建一个templatetags文件夹， ![image](http://hysyeah.top/wp-content/uploads/2017/09/笔.png) 2.utils.py

    from django import template
    
    register = template.Library()
    
    @register.filter
    def val_type(val):
        return type(val).__name__
    
    

3.此函数是返回变量的类型名，在模版文件中通过

    {% load utils %}
    

导入

    { { val|val_type }}
    

返回变量的类型