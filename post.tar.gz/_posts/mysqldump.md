---
title: mysqldump
tags:
  - mysql
url: 1772.html
id: 1772
categories:
  - 数据库
date: 2019-04-12 07:50:25
---

`mysqldump`是`mysql`提供的用于数据备份的工具，通过再次执行`SQL`语句以达到恢复数据的目的（生产环境慎用)。`mysqldump`的优势在于方便和在恢复之前可以查看dump文件甚至修改文件内容。通常用于开发测试，及数据量比较小的情况下，当数据量大的情况下可能dump所花费的时间的时间是可以接受的，但恢复的时候会消耗大量的磁盘I/O。 1.`mysqldump`所需的权限 `mysqldump`所需要的权限跟其所dump的对象有关，若备份表则需要`SELECT`权限，若备份视图，则需要`SHOW VIEW`权限，若备份触发器，则需要`TRIGGER`权限。 2.锁表问题 `mysqldump`默认会锁住需要dump的表 3.`mysqldump`常用参数

    mysqldump [options] > dump.sql
    

#### --options

|  Format | 描述  |
| ------------------------ | ------------ |
| --all-databases |  备份所有数据库 |
| --databases  | 指定所需备份的数据库  |
|--no-data|不备份数据|
|--user|用户名|
|--host|IP或主机名|
|--port|端口|
|--lock-all-table|锁住需要dump数据库的所有表，会使选项--lock-tables和--single-transaction关闭|
|--lock-tables|会锁住每个数据库中需要dump的表|
|--password|密码|
|--single-transaction|只适用于InnoDB引擎，当执行dump命令时，客户端会发一条START TRANSACTION的语句给server,会dump事务开始时的数据库状态，不会锁表，所以不会对应用造成影响|
|--quick|一行一行进行dump，不会将数据缓存在内存中，每次都需要写文件，速度会变慢|
|--skip-quick|先将数据缓存在内存中，再一次写到文件中，速度较快，但不适用的大表|
|--tables|指定表,会覆盖--databases选项|



详细参数[请参考](https://dev.mysql.com/doc/refman/5.7/en/mysqldump.html)   
4.示例

    # dump
    mysqldump -hlocalhost -uroot -pxxxx --databases  test --tables table_a table_b > test.sql
    
    # restore
    mysql -uroot -pxxxx test < test.sql
