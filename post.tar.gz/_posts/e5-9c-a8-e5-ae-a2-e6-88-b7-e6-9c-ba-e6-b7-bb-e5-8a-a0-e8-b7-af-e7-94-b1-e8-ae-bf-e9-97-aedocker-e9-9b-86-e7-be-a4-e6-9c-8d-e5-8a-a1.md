---
title: 在客户机添加路由访问docker集群服务
url: 889.html
id: 889
categories:
  - 未分类
date: 2018-05-17 16:29:54
tags:
---

在局域网(网段为10.68.2.0/24)中通过docker搭建了spark服务，docker容器的网段为192.168.2.0/24。 在相同网段的客户机中要访问docker容器中的服务，可以在客户机添加路由

    # linux环境下 10.68.2.xx:为网关，也就是搭建服务电脑的ip
    sudo route add -net 192.168.2.0 netmask 255.255.255.0 gw 10.68.2.xx
    
    # windows环境下
    route add 192.168.0.0 mask 255.255.0.0 10.68.2.xxx