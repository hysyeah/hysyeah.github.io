---
title: '执行go get出现 go: GOPATH entry is relative错误'
url: 763.html
id: 763
categories:
  - GO
date: 2018-04-01 21:12:39
tags:
---

    将~/.zshrc文件中 
    export GOPATH="/home/hys/mycode/go:/home/hys/mycode/go/gopl:$GOPATH"
    
    改为
    export GOPATH="/home/hys/mycode/go:/home/hys/mycode/go/gopl"