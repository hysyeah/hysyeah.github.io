---
title: extern "C"
url: 402.html
id: 402
categories:
  - C语言
date: 2017-11-11 10:33:47
tags:
---

C++为了与C兼容，在符号的管理上，C++提供了一 个用来声明或定义C符号的"extern "C""关键字。C++编译器会将在extern "C"的大括号内部的代码当作C语言处理，C++的名称修饰机制将不起作用。 ![](http://hysyeah.top/wp-content/uploads/2017/11/1.png) 很多时候我们会碰到有些头文件声明了一些C语言的 函数和全局变量，但是这个头文件可能会被C语言代码或c++代码包含。比 如很常见的，我们的C语言库函数中的string.h中声明了memset这个函数，它的原型如下：

    void *memset (void *, int ,size);
    
    

如果不加任何处理，当我们的C语言程序包含string.h的时候，并且用到了memset这个函数 ，编译器会将memset符号引用正确处理；但是在C++语言中，编译器会认为这个memset函数是一个C++函数，将memset的符号修饰成\_Z6memsetPvii,这样链接器就无法与C语言库中的memset符号进行链接。所以对于C++来说，必须使用extern "C"来声明memset这个函数。但是C语言又不支持extern "C"语法，如果为了兼容C语言和C++语言定义两套头文件，未免于麻烦。幸好我们有一种很好的方法可以解决上述问题，就是使用C++的宏"\_\_cplusplus",C++编译会在编译c++的程序默认定义这个宏，我们可以使用条件宏来判断当前编译单元是不是C++代码。具体代码如下：

    #ifdef __cplusplus
    
    extern "C" {
    
    #endif
    
    void *memset (void *, int,  size_t);
    
    #ifdef __cplusplus
    
    }
    
    #endif
    
    

如果当前编译单元是C++代码，那么memset会在extern "C"里面被声明；如果是C代码，就直接声明。 参考： 1.程序员的自我修养 2.[https://www.cnblogs.com/stonecrazyking/archive/2006/09/23/512552.html](https://www.cnblogs.com/stonecrazyking/archive/2006/09/23/512552.html)