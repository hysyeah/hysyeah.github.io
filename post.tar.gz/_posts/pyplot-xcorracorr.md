---
title: 'pyplot.[xcorr,acorr]'
url: 426.html
id: 426
categories:
  - pyplot
  - python科学计算
date: 2017-11-26 11:57:41
tags:
---

自相关（英语：Autocorrelation），也叫序列相关\[1\]，是一个信号于其自身在不同时间点的互相关。非正式地来说，它就是两次观察之间的相似度对它们之间的时间差的函数。它是找出重复模式（如被噪声掩盖的周期信号），或识别隐含在信号谐波频率中消失的基频的数学工具。它常用于信号处理中，用来分析函数或一系列值，如时域信号。 在统计学中，互相关有时用来表示两个随机矢量X和Y之间的协方差cov（X, Y），以与矢量X的“协方差”概念相区分，矢量X的“协方差”是X的各标量成分之间的协方差矩阵。 在信号处理领域中，互相关（有时也称为“互协方差”）是用来表示两个信号之间相似性的一个度量，通常通过与已知信号比较用于寻找未知信号中的特性。它是两个信号之间相对于时间的一个函数，有时也称为滑动点积，在模式识别以及密码分析学领域都有应用。

    matplotlib.pyplot.acorr(x, hold=None, data=None, **kwargs) #x的自相关
    
    matplotlib.pyplot.xcorr(x, y, normed=True, detrend=<function detrend_none>, usevlines=True, maxlags=10, hold=None, data=None, **kwargs) #画出x与y的互相关关系
    
    

    import matplotlib.pyplot as plt
    import numpy as np
    
    np.random.seed(0) #用于指定随机数生成时所用算法开始的整数值，如果使用相同的seed( )值，则每次生成的随即数都相同，如果不设置这个值，则系统根据时间来自己选择这个值，此时每次生成的随机数因时间差异而不同
    
    x, y = np.random.randn(2, 100)#返回一个二维，长度为100的数组
    fig = plt.figure() #添加一个画布
    ax1 = fig.add_subplot(211)#添加个子图，两行一列中的第一个图
    ax1.xcorr(x, y, usevlines=True, maxlags=50, normed=True, lw=2)#互相关函数
    ax1.grid(True) #添加网格
    ax1.axhline(0, color='black', lw=2)
    
    ax2 = fig.add_subplot(212, sharex=ax1)
    ax2.acorr(x, usevlines=True, normed=True, maxlags=50, lw=2)#自相关函数
    ax2.grid(True)
    ax2.axhline(0, color='black', lw=2)
    
    plt.show()
    
    

![image](http://hysyeah.top/wp-content/uploads/2017/11/QQ图片20171118102729.png)

* * *

参考： 1.[http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.xcorr](http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.xcorr)