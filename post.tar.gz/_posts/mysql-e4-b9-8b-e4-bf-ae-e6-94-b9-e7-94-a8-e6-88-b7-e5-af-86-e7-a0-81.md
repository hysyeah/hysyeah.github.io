---
title: mysql之修改用户密码
url: 1665.html
id: 1665
categories:
  - 数据库
date: 2019-02-18 21:54:43
tags:
---

mysql中有几种方式可以修改用户密码。 1.直接修改mysql.user中的password字段

    update mysql.user set password=password('hello') where user='t'
    flush privileges;
    

2.使用`create user`,`grant`或`set password`

    create user t identified by 'password';
    
    grant select on cloud.* to 'root'@'10.68.6.66' identified by 'password'
    
    set password for 'root'@'localhost' ='auth_string'; 在5.5.60中执行报错
    
    set password for 'root'@'localhost' = password('auth_string');  在5.7.6中已废弃这种语法，将来会移除