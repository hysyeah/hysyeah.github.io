---
title: python之else
url: 1549.html
id: 1549
categories:
  - python
date: 2018-08-24 00:20:05
tags:
---

    In [1]: def print_prime(n):
       ...:     for i in range(2, n):
       ...:         for j in range(2, i):
       ...:             if i % j == 0:
       ...:                 break
       ...:         else:
       ...:             print("%d is a prime number" %i)
       ...:
    
    In [2]: print_prime(10)
    2 is a prime number
    3 is a prime number
    5 is a prime number
    7 is a prime number
    

当循环自然结束时(循环条件为假)时else从句会被执行一次，而当循环是由`break`语句中断时，`else`子句不会被执行。与`for`语句相似，`while`语句中的`else`子句的语意是一样的：`else`块在循环正常结束和循环条件不成立时被执行。

* * *

异常处理中的`else`  
`try`块没有抛出任何异常时，执行`else`块

    def save(db, obj):
        try:
            db.execute("a sql", obj.attr1)
        except DBErrror:
            db.rollback()
        else:
            db.commit()    # 未发生异常时执行
    

* * *

参考： 1.编写高质量代码-改善Python程序的91个建议