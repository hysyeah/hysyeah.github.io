---
title: supervisor can not find 'uwsgi' command
url: 344.html
id: 344
categories:
  - 未分类
date: 2017-11-04 15:57:56
tags:
---

在一次关掉supervisor控制的进程，再进行开启的时候，报supervisor can not find 'uwsgi' command错误，而\[program:uwsgi\]是存在于配置文件中的。此时杀死\[program:uwsgi\]中command所执行的命令的进程，再将配置文件中的autorestart=True注释掉，reload后重新启动进程即可。

* * *

1.[http://m.blog.csdn.net/lf8289/article/details/45478639](http://m.blog.csdn.net/lf8289/article/details/45478639) 2.[https://www.v2ex.com/t/326059](https://www.v2ex.com/t/326059)