---
title: racket list类型
url: 1308.html
id: 1308
categories:
  - Racket
date: 2018-07-11 16:15:31
tags:
---

#### 创建一个list,并赋值给变量lst

    > (define lst (list 1 2 3 4))
    > lst
    '(1 2 3 4)
    

#### list内置方法

    > (length lst)                      ;列表长度
    4
    > (list-ref lst 0)                  ;根据下标取值
    1
    > (append lst (list 5 6 7))         ;连接两个列表
    '(1 2 3 4 5 6 7)
    > (reverse lst)                     ;反转列表
    '(4 3 2 1)
    > (member 5 (list 1 2 3))           ;判断元素是否存在于列表中
    #f
    > (map sqrt (list 1 4 9 16))        ;依次对列表中的每个元素求算术平方根
    '(1 2 3 4)
    
    > (andmap string? (list "a" "b" 6)) ;判断列表中元素是否全部为string,
    #f
    > (ormap number? (list "a" "b" 6))  ;判断列表中元素是否存在number
    
    > (filter string? (list "a" "b" 6)) ;对列表元素进行过滤
    '("a" "b")
    
    > (first (list 1 2 3))              ;返回列表中的第一个元素
    1
    > (rest (list 1 2 3))               ;返回除第一个元素的剩余元素
    '(2 3)
    

* * *

参考： 1.[官方文档](https://docs.racket-lang.org/guide/Lists__Iteration__and_Recursion.html)