---
title: osi模型与tcp/ip
tags:
  - tcp/ip
url: 1892.html
id: 1892
categories:
  - 未分类
date: 2019-06-11 23:09:03
---

OSI(open systems interconnection)开放系统互连。 OSI是一个七层的概念模型，提供给开发者一个必须的、通用的概念以便开发完善、可以用来解释连接不同系统的框架。 OSI模型与TCP/IP对应的关系： ![](http://hysyeah.top/wp-content/uploads/2019/06/tcp-ip-tour-1.png) TCP/IP通常被认作一个四层协议系统。 1.链路层/网络接口层：处理底层物理接口细节 2.网络层：处理分组在网络中的活动 3.传输层：主要为两台主机上的应用程序提供端到端的通信。TCP和UDP在这一层。 4.应用层：负责处理特定的应用程序细节

* * *

参考： 1.《TCP/IP协议详解1》