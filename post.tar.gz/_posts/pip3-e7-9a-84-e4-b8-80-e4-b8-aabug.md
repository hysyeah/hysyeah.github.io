---
title: pip3的一个bug
url: 1706.html
id: 1706
categories:
  - 未分类
date: 2019-03-11 21:24:23
tags:
---

![](http://hysyeah.top/wp-content/uploads/2019/03/pip3.png)

    import sys
    
    from pip import main
    if __name__ == '__main__':
        sys.exit(main())
    

#### sudo vim /usr/bin/pip3 #将上面代码改为如下

    import sys
    
    from pip import __main__
    if __name__ == '__main__':
        sys.exit(__main__._main())
    

* * *

参考： 1.[stackoverflow](https://stackoverflow.com/questions/28210269/importerror-cannot-import-name-main-when-running-pip-version-command-in-windo)