---
title: ubuntu未发现Python.h文件
url: 548.html
id: 548
categories:
  - python
date: 2017-11-30 21:55:18
tags:
---

##### /usr/include/python3.5m下没有Python.h头文件

    sudo apt-get install python3-dev