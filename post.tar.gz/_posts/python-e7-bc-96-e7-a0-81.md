---
title: python编码
url: 293.html
id: 293
categories:
  - python
date: 2017-10-02 13:02:16
tags:
---

#### python2中的默认编码为ASCII,在python3改为了unicode。

![image](http://hysyeah.top/wp-content/uploads/2017/10/u.jpg) ![image](http://hysyeah.top/wp-content/uploads/2017/10/u-1.jpg)

#### python2中,python3中已经没有(unicode,basestring)

    unicode_type = unicode
    
    string_type = basestring
    
    

python3中

    unicode_type = str
    
    string_type = bytes
    
    

* * *

参考： 1.[http://www.jianshu.com/p/2bb8a1300bfd](http://www.jianshu.com/p/2bb8a1300bfd)