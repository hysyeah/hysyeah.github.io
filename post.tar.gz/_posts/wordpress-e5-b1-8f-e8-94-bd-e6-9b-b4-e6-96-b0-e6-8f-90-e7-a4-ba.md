---
title: wordpress屏蔽更新提示
url: 196.html
id: 196
categories:
  - 未分类
date: 2017-09-15 18:11:11
tags:
---

wordpress/wp-includes/update.php 在最后面添加

    add_filter('pre_site_transient_update_core', create_function('$a', "return null;"));//关闭核心提示
    add_filter('pre_site_transient_update_plugins', create_function('$a', "return null;"));//关闭插件提示
    add_filter('pre_site_transient_update_themes', create_function('$a', "return null;"));//关闭主题提示
    
    

并注释掉

    //add_action( 'admin_init', '_maybe_update_plugins' );
    
    //add_action( 'admin_init', '_maybe_update_themes' );
    
    

重启php-fpm即可。