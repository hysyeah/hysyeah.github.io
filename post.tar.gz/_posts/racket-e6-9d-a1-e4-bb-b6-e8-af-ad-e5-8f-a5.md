---
title: racket条件语句
url: 1295.html
id: 1295
categories:
  - Racket
date: 2018-07-11 15:32:54
tags:
---

#### ( if ‹expr› ‹expr› ‹expr› )

#### if语句，若2>3输出"bigger",否则输出"smaller"

    > (if (> 2 3)
          "bigger"
          "smaller")
    

#### ( cond {\[ ‹expr› ‹expr›* \]}* )(相当于C中的switch,else相当于c中的default)

    > (define (reply-more s)
        (cond
          [(equal? "hello" (substring s 0 5))
           (string-append "this is " s)]
          [(equal? "goodbye" (substring s 0 7))
           (string-append "this is " s)]
          [else "hehe"]))
    
    > (reply-more "hello")
    "this is hello"
    > (reply-more "dfdfllfd")
    "hehe"
    

#### ( and ‹expr›* )(当所有表达式为真时，返回真)

    > (define (is-digit v)
        (if (and (number? v) (> v 0) (< v 10))
            "v is a number and value is between 1-9"
            "v is not a number"))
    > (is-digit 5)
    "v is a number and value is between 1-9"
    

#### ( or ‹expr›* )(当任一表达式为真时，返回真)

    > (define (str-num v)
        (if (or (string? v) (number? v))
            "v is string or number"
            "v is not string or number"))
    

* * *

参考： 1.[官方文档](https://docs.racket-lang.org/guide/syntax-overview.html)