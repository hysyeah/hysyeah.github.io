---
title: Go接口
url: 1506.html
id: 1506
categories:
  - GO
date: 2018-08-18 19:44:28
tags:
---

接口类型是对其它类型行为的抽象和概括；因为接口类型不会和特定的实现细节绑定在一起，通过这种抽象的方式我们可以让我们的函数更加灵活和更具有适应能力。 接口类型具体描述了一系列方法的集合，一个实现了这些方法的具体类型是这个接口类型的实例。 一个类型如果拥有一个接口需要的所有方法，那么这个类型就实现了这个接口。

    /* Abs()是interface类型Abser定义的方法，而MyFloat实现了该方法，所以，MyFloat实现了Abser接口
    package main
    
    import (
        "fmt"
        "math"
    )
    
    type Abser interface {
        Abs() float64
    }
    
    type MyFloat float64
    
    func (f MyFloat) Abs() float64 {
        if f < 0 {
            return float64(-f)
        }
        return float64(f)
    }
    
    func main() {
        var a Abser
        f := MyFloat(-math.Sqrt2)
        a = f  // a MyFloat implements Abser
        fmt.Println(a.Abs())
    
    

interface{}被称为空接口，因为空接口类型对实现它的类型没有要求，所以我们可以将任意一个值赋给空接口类型。

    var any interface{}
    any = true
    any = 12.34
    any = "hello"
    any = map[string]int{"one": 1}
    any = new(bytes.Buffer)
    

格式化输出

    // 实现了String方法的类型，称作实现了Stringer接口。Stringer接口为此类型提供了原始的输出格式
    type Stringer interface {
            String() string
    }
    

    package main
    
    import "fmt"
    
    type IPAddr [4]byte
    
    func main() {
        addrs := map[string]IPAddr{
            "loopback":  {127, 0, 0, 1},
            "googleDNS": {8, 8, 8, 8},
        }
        for n, a := range addrs {
            fmt.Printf("%v: %v\n", n, a)
        }
    }
    

![](http://hysyeah.top/wp-content/uploads/2018/08/ip.png) 为类型IPAddr实现Stringer接口

    package main
    
    import "fmt"
    
    type IPAddr [4]byte
    
    func (ip IPAddr) String() string {    
        return fmt.Sprintf("%v.%v.%v.%v", ip[0], ip[1], ip[2], ip[3])
    }
    
    func main() {
        addrs := map[string]IPAddr{
            "loopback":  {127, 0, 0, 1},
            "googleDNS": {8, 8, 8, 8},
        }
        for n, a := range addrs {
            fmt.Printf("%v: %v\n", n, a)
        }
    }
    

![](http://hysyeah.top/wp-content/uploads/2018/08/ip1.png)

#### 是不是和python中的`__str__`有什么不可描述的联系？？

* * *

参考： 1.The Go Programming Language 2.[https://studygolang.com/articles/2652](https://studygolang.com/articles/2652)