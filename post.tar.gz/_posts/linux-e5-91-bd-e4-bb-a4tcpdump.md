---
title: linux命令tcpdump与tcp zero window
tags:
  - linux
  - tcp/ip
url: 1836.html
id: 1836
categories:
  - 未分类
date: 2019-06-01 15:20:25
---

    example:
    tcpdump -i ens250 port 34495 -w t.pcap
    # -i: 指定监听网卡
    # port: 指定监听端口
    # -w file: 将数据保存在外部文件中，以.pcap结尾的文件可以通过wireshark打开
    
    

常用选项：

    -c count                  # 捕获count个packet后退出
    

* * *

##### tcp zero window

`TCP Window size`是指机器在一个`TCP`session中可以接收多大的数据量。类似于`TCP`中的接收缓冲，当客户端和服务端建立连接时，客户端会通过`Window Size`告诉服务端可以接收多少数据。 当建立TCP连接后，服务端开始向客户端发送数据，客户端会减少`Window Size`当接收的数据存在于缓冲中时，同时客户端会在缓冲中处理数据，清空缓冲以便接收更多的数据。通过`TCP ACK frames`客户端会告诉服务端还可以接收多大的数据。当`TCP Window Size`等于0时，我们称为零窗口，此时客户端不能再接收数据，直到缓冲中的数据被清空。

* * *

参考： 1.[https://wiki.wireshark.org/TCP%20ZeroWindow](https://wiki.wireshark.org/TCP%20ZeroWindow)