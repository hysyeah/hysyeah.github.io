---
title: centos安装mysqlclient
url: 335.html
id: 335
categories:
  - Python Web
date: 2017-10-28 07:52:05
tags:
---

centos安装 mysqlclient失败，需先安装

    yum install mysql-devel
    

    pip install mysqlclient
    

* * *

ubuntu

    apt-get install libmysqlclient-dev python3-dev