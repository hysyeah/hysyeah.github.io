---
title: racket number类型
url: 400.html
id: 400
categories:
  - Racket
date: 2018-07-16 16:13:35
tags:
---

    > (number? 1)                         ;判断是否是number类型
    #t
    
    > (complex? 1+2i)                     ;判断是否是complex类型
    #t
    > (complex? 1)                        ;所有number都是complex类型，1==1+0i
    #t
    
    > (real? 1)                           ;判断是否是实数
    #t
    > (real? 1+i)
    #f
    
    > (rational? 0.3)                     ;判断是否是有理数
    #t
    
    > (integer? 1)                        ;判断是否是整数
    #t
    > (integer? 1.0)
    #t
    > (integer? 2.3)
    #f
    
    > (exact? 1)                           ;判断是否是精确值
    #t
    > (exact? 1.0)
    #f
    
    > (inexact? 1)                         ;判断是否是非精确数
    #f
    > (inexact? 1.0)
    #t
    
    > (exact-integer? 1)                   ;相当于 (and (integer? v) (exact? v))
    #t
    > (exact-integer? 4.0)
    #f
    
    > (negative? -10)                      ;判断是否是负数，返回(> x 0)
    #t
    > (negative? -0.0)
    #f
    
    > (positive? 10)                       ;判断是否是正数，返回(> x 0)
    #t
    > (positive? 0.0)
    #f
    
    > (even? 2)                            ;判断是否是偶数，0属于偶数
    #t
    > (even? 0)
    #t
    
    > (odd? 11)                            ;判断是否是奇数
    #t
    
    > (exact-nonnegative-integer? 0)       ;相当于(and (exact-integer? v) (not (negative? v)))
    #t
    
    > (exact-positive-integer? 1)          ;相关于(and (exact-integer? v) (positive? v))
    #t
    
    > (inexact-real? 1)                    ;相当于(and (real? v) (inexact? v))
    #f
    
    > (flonum? 0)                          ;判断是否是浮点数，等同于(double-flonum? v)
    #f
    > (flonum? 0.0)
    #t
    
    > (single-flonum? 1.0)                  ;判断是否是单精度浮点数
    #f
    
    > (zero? 0)                             ;判断是否等于0
    #t
    > (zero? -0.0)
    #t
    
    > (truncate 2.5)                        ;对数进行截断
    2.0
    > (truncate -2.5)
    -2.0
    
    > (numerator 3)                         ;返回数的分子
    3
    > (numerator 14/3)
    14
    
    > (denominator 5)                       ;返回数的分母
    1
    > (denominator 17/4)
    4
    
    > (expt 2 3)                            ;等于2**3
    8
    

* * *

参考： 1.[官方文档](https://docs.racket-lang.org/reference/number-types.html)