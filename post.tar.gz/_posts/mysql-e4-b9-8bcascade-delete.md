---
title: mysql之cascade delete
url: 1703.html
id: 1703
categories:
  - 数据库
date: 2019-03-09 14:51:35
tags:
---

`ON DELETE CASCADE`表示如果父表中记录删除，则子表中引用了父表记录的行都会被删除。

    # 新建表
    CREATE TABLE a (
    id int not null,
    name varchar(20),
    primary key(id)
    );
    
    CREATE TABLE b (
    id int not null,
    a_id int not null,
    CONSTRAINT `fk_a__id` FOREIGN KEY (`a_id`) REFERENCES `a` (`id`) ON DELETE CASCADE
    );
    
    

![](http://hysyeah.top/wp-content/uploads/2019/03/cascade.png) 当设置`SET GLOBAL FOREIGN_KEY_CHECKS=0;(下次登录生效)`时，级联删除并不会生效。 当我们使用语句`delete from a`时，mysql会将b表中的数据也会删除，那删除b表中的数据这一操作会不会记在binlog中呢？？ 经过验证不管设置何种`binlog_format`b表中的数据变化并不会记录在日志文件中。级联操作是根据存储引擎通过外键关系来进行操作的，并不会体现在日志文件中。mysql文档中有详细的[解释](https://dev.mysql.com/doc/refman/5.7/en/innodb-and-mysql-replication.html)