---
title: pg_dump和pg_restore的使用
url: 1659.html
id: 1659
categories:
  - 数据库
date: 2019-02-17 10:12:04
tags:
---

##### pg_dump 从pg database中提取数据到一个脚本文件或其它归档文件

    pg_dump和pg_resotre拥有相同的参数
    
    -a   --data-only   # 只复制数据，不复制表结构
    -b   --blobs       #包括大对象(在pg中什么是large objects),-b是默认生效的，在指定--schema,--table,--schema-only的情况下除外
    -B   --no-blobs    #不包括大对象，当同时指定-b,-B时，-b生效
    -c   --clean       #在创建之前会先删除database
    -C   --create      #创建database,如果同时指定--clean,会先删除database再创建新的database
    -E encoding  --encoding=encoding  # 指定数据库字符集，默认使用database的字符集
    -f file  --file=file  #将输出到指定文件中
    -j njobs --jobs=njobs #指定进程数
    -n schema --schema=schema  #指定要dump的schema
    -N schema --exclude-schema=schema  #指定不进行dump的schema
    -O --no-owner #不设置ownership
    -s --schema-only #只复制表结构
    -t table --table=table #指定需要复制的表，当同时指定-n,-N，-t时，-n,-N不生效
    -T table --exclude-table=table #指定不需要复制的表
    -x --no-privileges --no-acl #不dump access privileges(grant/revoke commands)
    --disable-triggers  #忽略触发器
    -d dbname --dbname=dbname  #指定连接的数据库
    -h host --host=host        #指定主机名
    -p port --port=port        #指定端口
    -U username --username=username  # 指定用户名
    
    

    create database ptldwh template template0; #To make an empty database without any local additions
    

    pg_dump -Fc -v -n 'public' --host=127.0.0.1 -p5433 --no-owner --no-privileges --username=ptldwhdata ptldwh -t host >ptldwh.dump
    
    -t 't_*' #指定要同步的表名
    
    pg_restore -n 'public' -Uroot --no-owner --no-privileges --disable-triggers -d ptldwh -t host ptldwh.dump
    

* * *

参考： 1.[pg_dump](https://www.postgresql.org/docs/10/app-pgdump.html) 2.[pg_restore](https://www.postgresql.org/docs/10/app-pgrestore.html)