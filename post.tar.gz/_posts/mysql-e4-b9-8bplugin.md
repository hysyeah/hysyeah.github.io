---
title: mysql之plugin
url: 1683.html
id: 1683
categories:
  - 数据库
date: 2019-02-23 09:31:56
tags:
---

mysql支持可插拔式的认证方式。 插拔式认证拥有以下能力： 1.可选择内置(native)的认证方式 2.外部认证方式，如`PAM, Windows login IDs, LDAP, Kerberos` 3.代理用户

*   mysql包括两种native认证方式`mysql_native_password, mysql_old_password`都是通过系统表`mysql.user`和密码hash算法实现的。

![](http://hysyeah.top/wp-content/uploads/2019/02/mysql_native_password.png) 认证的插件都在存在于客户端和服务端的，服务端的是内置于mysql服务器中。客户端的则在于libmysqlclient中。 - SHA-256 Pluggable Authentication 这种认证方法是比mysql\_native\_password认证方法安全性更高，采用SHA-256哈希算法对明文进行加密。 ![](http://hysyeah.top/wp-content/uploads/2019/02/sha256-pulgin.png) 创建SHA-256认证的用户

    CREATE USER 'sha256user'@'localhost'
    IDENTIFIED WITH sha256_password BY 'password';
    

*   Client-Side Cleartext Pluggable Authentication，存储明文 ![](http://hysyeah.top/wp-content/uploads/2019/02/cleartext.png)
    
*   PAM认证 外部认证方式，使mysql服务器通过PAM服务来进行用户认证
    
*   Windows认证 外部认证方式，使mysql服务器通过原生Windows服务授权客户端连接，当用户登录了 Windows也可以连接mysql服务器(通过环境信息确认用户，不用额外的密码)
*   LDAP认证 外部认证方式，Lightweight Directory Access Protocol
*   No-Login 认证 阻止任何使用此plugin的用户连接mysql服务。此种方式不允许直接登录可以使用代理 方式登录
*   Socket Peer-Credential认证 本地用户通过连接Unix socket文件进行认证。
*   Test Pluggable Authentication 测试插件用于测试用户认证是否成功，而且会把是否成功的日志打印到server error log。这个插件的目的是用于测试和开发，也可以作为一个如何写认证插件的例子。

* * *

参考： 1.[https://dev.mysql.com/doc/refman/5.7/en/pam-pluggable-authentication.html](https://dev.mysql.com/doc/refman/5.7/en/pam-pluggable-authentication.html)