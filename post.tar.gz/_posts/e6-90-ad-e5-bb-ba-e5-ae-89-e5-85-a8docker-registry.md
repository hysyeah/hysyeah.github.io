---
title: 搭建安全Docker Registry
url: 661.html
id: 661
categories:
  - 未分类
date: 2018-01-23 10:48:10
tags:
---

    1.安装registry
    docker pull registry
    
    2.制作证书
    openssl req -newkey rsa:2048 -nodes -sha256 -keyout certs/domain.key -x509 -days 365 -out certs/domain.crt
    

![image](http://hysyeah.top/wp-content/uploads/2018/01/ca.png)

    3.docker run -d -p 5000:5000 --restart=always --name registry \
      -v /data/registry:/var/lib/registry \
      -v /certs:/certs \
      -e REGISTRY_HTTP_TLS_CERTIFICATE=/certs/domain.crt \
      -e REGISTRY_HTTP_TLS_KEY=/certs/domain.key \
    
    .4.在客户端安装证书
    sudo mkdir -p /etc/docker/certs.d/d.hysyeah.top:5000
    sudo cp domain.crt /etc/docker/certs.d/d.hysyeah.top:5000/ca.crt
    sudo service docker restart
    
    5.docker pull busybox
    
    6.docker tag busybox d.hysyeah.top:5000/busybox 
    
    7.docker push d.hysyeah.top:5000/busybox