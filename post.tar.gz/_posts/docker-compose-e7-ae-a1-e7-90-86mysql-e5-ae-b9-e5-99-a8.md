---
title: Docker Compose管理mysql容器
url: 659.html
id: 659
categories:
  - 未分类
date: 2018-01-22 21:52:39
tags:
---

Dockerfile用于管理一个单独的应用容器，Docker Compose用于管理多个容器。

    1.sudo pip install docker-compose
    
    2.docker pull mysql
    
    3.mkidr mysql
      vim docker-compose.yml
    

#### docker-compose.yml(包括version,services,networks三大部分)

    version: '2'
    services:
      mysql:
        image: mysql   #指定镜像为mysql
        networks:
           mysqlnet:
              ipv4_address: xxx.xxx.xxx.xxx #设置ip地址
        volumes:
        - /etc/mysql/:/etc/mysql        #将宿主机的/etc/mysql/映射到容器中，即容器上使用宿主中的/etc/mysql/
        restart: always
        environment:                    #设置环境变量
          MYSQL_ROOT_PASSWORD: root
          MYSQL_DATABASE: test
          MYSQL_USER: hys
          MYSQL_PASSWORD: hello
        expose:
          - "3307"
        ports:
          - "3307:3306"
    networks:
      mysqlnet:
        driver: bridge
        ipam:
          driver: default
          config:
          - subnet: xxx.xxx.xxx.0/26
    

    docker-compose up -d #启动后，可访问mysql服务