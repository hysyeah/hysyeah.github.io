---
title: pandas数据类型DataFrame及基本操作
url: 325.html
id: 325
categories:
  - python科学计算
date: 2018-05-23 10:54:17
tags:
---

    import pandas as pd
    df = pd.DataFrame()
    df[:n] #取前n行
    
    df.loc[行标签,列标签]
    df.loc['a':'b']#选取ab两行数据,ab为行名
    df.loc[:,'one']#选取one列的数据
    
    df.iloc(n)    #取第n行
    df.iloc[:,0]  #取第0列
    df.iloc[:,[0,1]] #取第0列和第1列
    
    df2 = df.fillna(pd.NaT)
    df.to_excel('foo.xlsx', sheet_name='Sheet1') #写入Excel
    
    df.dropna(how='any') #当有一项为NaN时，丢弃整行或整列
    df.dropna(how='all') #当所有项都为NaN时，丢弃整行或整列
    
    df.describe()        #展示df的相关信息
    

    # 创建DataFrame
    In [63]: import pandas as pd
    In [64]: d ={'A':[1,2,3],'B':[4,5,6]}
    In [65]: df = pd.DataFrame(df,index=['x','y','z'])
    
    In [67]: df
    Out[67]:
       A  B
    x  1  4
    y  2  5
    z  3  6