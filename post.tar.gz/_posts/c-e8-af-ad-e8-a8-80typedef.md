---
title: c语言typedef
url: 577.html
id: 577
categories:
  - C语言
date: 2017-12-09 22:35:37
tags:
---

    /*定义identifier为宏，指令为identifier后的一系列指令（以前认为只能是一句）*/
    #define identifier replacement-list(optional)
    
    #define PyObject_HEAD                   \
        Py_ssize_t ob_refcnt;               \
        struct _typeobject *ob_type;
    
    typedef struct _object {
        PyObject_HEAD
    } PyObject;
    //相当于：
    typedef struct _object {
        Py_ssize_t ob_refcnt;
        struct _typeobject *ob_type;
    } PyObject;
    
    

* * *

    #include <stdio.h>
    
    #define T int b;int c;
    typedef struct gg {
        T
    } gg;
    int main(int argc, char *argv[]){
        gg g = {1, 2};
        printf("%d\n", g.b);
        printf("%d\n", g.c);
        return 0;
    }
    输出：
    1
    2
    

* * *