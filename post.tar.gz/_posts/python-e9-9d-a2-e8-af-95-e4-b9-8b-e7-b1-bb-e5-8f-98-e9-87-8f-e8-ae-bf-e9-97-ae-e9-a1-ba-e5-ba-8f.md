---
title: python面试之类变量访问顺序
url: 1522.html
id: 1522
categories:
  - python
date: 2018-08-20 23:45:48
tags:
---

    class A:
        a = 1
    
    a, b, c = A(), A(),A()
    
    print(a.a, b.a, c.a)
    
    a.a = 2
    A.a = 3
    print(a.a, A.a, c.a)
    
    print(a.__dict__, A.__dict__, c.__dict__)
    
    # 输出
    (1, 1, 1)           #实例对象字典为空，从类的字典寻找变量，所以输出都为1
    (2, 3, 3)           #实例a有了自己的字典，c没有自己的字典，从类的字典寻找变量，所以为3
    ({'a': 2}, {'a': 3, '__module__': '__main__', '__doc__': None}, {})