---
title: ubuntu上搭建git仓库
url: 727.html
id: 727
categories:
  - 未分类
date: 2018-03-21 11:41:14
tags:
---

    1.安装git ,git-core,openssh-server
    2.创建用户git,
    3.客户端生成公钥，ssh-keygen -t rsa -C "xxx@126.com"
    5.将客户端公钥添加到服务端的~/.ssh/authorized_keys文件下
    6.git –bare init /home/git/myRep.git  #在服务端建一个空的仓库
    7.在客户端输入命令拉取代码
    git clone git@gitServerIP:/home/git/myRep.git
    
    
    8.在myRep.git下的hooks 新建post-receive,
    添加git --work-tree=/home/wwwroot/hehe checkout -f
    设置工作目录(代码存放的目录)，每次提交代码后将会触发post-receive下的脚本,
    目标目录必须先创建,注意文件夹git用户写入权限