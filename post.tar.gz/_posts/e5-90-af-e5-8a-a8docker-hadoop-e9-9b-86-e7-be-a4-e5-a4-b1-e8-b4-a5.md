---
title: 启动docker hadoop集群失败
url: 668.html
id: 668
categories:
  - 未分类
date: 2018-02-01 12:52:01
tags:
---

    启动hadoop发生失败，查看日志文件
    docker hadoop Does not contain a valid host:port authority 
    
    从google得知，网络信息不能带下划线
    

##### 解决方法

##### 1.docker network ls

    发现docker网络中NAME:dockerpro_sparknet中含有下划线
    NETWORK ID          NAME                 DRIVER              SCOPE
    321147ce790d        bridge               bridge              local
    0fd542a85347        dockerpro_hsnet      bridge              local
    fa6a55dd5ed3        dockerpro_sparknet   bridge              local
    

##### 2.docker network create -d bridge --subnet 192.168.2.0/24 sparknet

##### 3.在docker-compose.yml中引用已创建的网络

    networks:
      default:
        external:
          name: sparknet
    

    version: '2'
    services:
      master:
        image: hyspark
        networks:
          default:
            ipv4_address: 192.168.2.10
    

##### 4.重新启动hadoop集群

![image](http://hysyeah.top/wp-content/uploads/2018/02/hdfsreport.png)

* * *

这问题够坑的。。