---
title: 一行把tuple转换为list
url: 138.html
id: 138
categories:
  - python
date: 2017-09-06 23:46:53
tags:
---

    In [16]: tup = ((1, 2, 3), (4, 5, 6))
    
    In [17]: list(map(list,tup))
    Out[17]: [[1, 2, 3], [4, 5, 6]]