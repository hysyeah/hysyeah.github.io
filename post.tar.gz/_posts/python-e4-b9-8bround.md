---
title: python之round
url: 1580.html
id: 1580
categories:
  - python
date: 2018-09-10 15:54:26
tags:
---

round(number\[, ndigits\]) Return number rounded to ndigits precision after the decimal point. If ndigits is omitted or is None, it returns the nearest integer to its input. For the built-in types supporting round(), values are rounded to the closest multiple of 10 to the power minus ndigits; if two multiples are equally close, rounding is done toward the even choice (so, for example, both round(0.5) and round(-0.5) are 0, and round(1.5) is 2). Any integer value is valid for ndigits (positive, zero, or negative). The return value is an integer if called with one argument, otherwise of the same type as number.

    # 如果小数部分为0.5,```round```向最近的偶数取整
    In [5]: round(10.5)
    Out[5]: 10
    
    In [6]: round(11.5)
    Out[6]: 12
    
    In [7]: round(10.4)
    Out[7]: 10
    
    In [8]: round(10.6)
    Out[8]: 11
    
    In [9]: round(-1.5)
    Out[9]: -2
    
    In [10]:  round(2.678, 2)
    Out[10]: 2.68
    
    In [11]:  round(2.676, 2)
    Out[11]: 2.68
    
    In [12]:  round(2.686, 2)
    Out[12]: 2.69
    
    
    # 当末位小数为5时，如果前一位也是小数而且是奇数，则返回指定位数;  
    # 如果前一位也是小数而且是偶数，则返回进1后的指定位数
    In [13]:  round(2.675, 2)
    Out[13]: 2.67
    
    In [14]:  round(2.685, 2)
    Out[14]: 2.69