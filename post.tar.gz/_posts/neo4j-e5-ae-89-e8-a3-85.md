---
title: neo4j安装
url: 1619.html
id: 1619
categories:
  - 未分类
date: 2018-10-14 13:17:45
tags:
---

Neo4j是一个高性能的,NOSQL图形数据库，它将结构化数据存储在网络上而不是表中。它是一个嵌入式的、基于磁盘的、具备完全的事务特性的Java持久化引擎，但是它将结构化数据存储在网络(从数学角度叫做图)上而不是表中。 应用场景： - 欺诈检测 - 实时推荐引擎 - Master data management(MDM) - Identity and access management(身份和访问管理-IAM) [来源](https://neo4j.com/why-graph-databases/?ref=footer)

* * *

1.安装依赖java,下载jdk 2.设置环境变量

    export JAVA_HOME=/opt/jdk1.8.0_191
    export JRE_HOME=/opt/jdk1.8.0_191/jre
    export CLASSPATH=.:$JAVA_HOME/lib:$JRE_HOME/lib:$CLASSPATH
    export PATH=$JAVA_HOME/bin:$JRE_HOME/bin:$PATH
    
    

* * *

1.[下载neo4j安装包](https://neo4j.com/download-center/#releases) 2.解压，添加环境变量

    cp neo4j-community-3.4.8-unix.tar.gz /opt
    tar -xf neo4j-community-3.4.8-unix.tar.gz
    export PATH="/opt/neo4j-community-3.4.8/bin:$PATH"
    
    

3.修改配置文件 neo4j默认只能从本机访问，因些修改conf/neo4j.conf,改为可从其它主机访问

    dbms.connectors.default_listen_address=0.0.0.0
    

4.开启neo4j服务`neo4j console` 5.打开浏览器输入`xxx.xxx.xxx.xxx:7474`,即可连接neo4j服务。默认用户名密码为:neo4j/neo4j,第一次会提示修改密码 6.连接后的界面如下 ![](http://hysyeah.top/wp-content/uploads/2018/10/neo4j.png)