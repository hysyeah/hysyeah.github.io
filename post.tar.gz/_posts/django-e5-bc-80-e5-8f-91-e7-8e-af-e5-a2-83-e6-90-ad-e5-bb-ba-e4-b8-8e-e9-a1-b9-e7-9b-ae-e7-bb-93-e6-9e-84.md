---
title: Django开发环境搭建与项目结构
url: 74.html
id: 74
categories:
  - Django
date: 2017-09-01 15:27:58
tags:
---

1.安装python3 2.安装virtualenv

    sudo apt-get install python3-virtualenv(ubuntu环境下)
    
    

或者

    pip3 install virtualenv
    
    

3.建立虚拟环境

    virtualenv venv
    
    

4.激活虚拟环境

    source venv/bin/activate(Linux环境）
    
    venv\Scripts\activate(Windows）
    
    

根据自己文件路径，需适当修改 5.在虚拟环境下通过pip3安装所需软件，如为旧项目，根据项目中的requests.txt文件安装所需依赖。

    pip3 install -r requests.txt
    
    

6.建立项目，APP(如新建好，则跳过此步骤)

    django-admin startproject xxxx
    
    django-admin startapp xxxx
    
    

7.项目结构 ![image](http://hysyeah.top/wp-content/uploads/2017/09/tree.png)

    - report/static 一些静态文件，如js,css文件
    - report/templates 项目模版
    - report/urls.py   路由配置文件
    - utils/sql.py     项目中用到的SQL查询语句
    - report/views/views.py 视图函数
    - report/views/xls_export.py xsl文件导出相关
    - xfbank/config    一些项目配置文件,dev_settings.py(测试环境),pro_settings.py(正式环境)
    - xfbank/urls.py   项目主配置urls文件</pre>
    

8.运行Django项目

    python manage.py runserver