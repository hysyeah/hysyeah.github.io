---
title: linux中有关网络相关参数的设置
tags:
  - linux
  - tcp/ip
url: 1850.html
id: 1850
categories:
  - 未分类
date: 2019-06-01 22:55:07
---

在`/etc/sysctl.conf`文件下存放着一些系统级别的参数，可以通过修改这个文件修改系统参数，当然也包括网络，比如`TCP`协议的相关设置。 修改完文件后，执行`sysctl -p`可使修改内容生效。 执行`sysctl -a`查看当前系统中生效的所有参数。 ![](http://hysyeah.top/wp-content/uploads/2019/06/sysctl_a.png) Linux常用网络内核参数：

|  参数 |  描述 |
| ------------ | ------------ |
| net.core.rmem_default  |  默认的 TCP 数据接收窗口大小（字节） |
| net.core.rmem_max  | 最大的 TCP 数据接收窗口（字节）  |
| net.core.wmem_default  | 默认的 TCP 数据发送窗口大小（字节）  |
| net.core.wmem_max  | 最大的 TCP 数据发送窗口（字节）  |
|  net.core.netdev_max_backlog | 在每个网络接口接收数据包的速率比内核处理这些包的速率快时，允许送到队列的数据包的最大数目  |
| net.core.somaxconn  | 定义了系统中每一个端口最大的监听队列的长度，这是个全局的参数  |
|  net.core.optmem_max | 表示每个套接字所允许的最大缓冲区的大小  |
| net.ipv4.tcp_mem  | 确定 TCP 栈应该如何反映内存使用，每个值的单位都是内存页（通常是 4KB）  第一个值是内存使用的下限；第二个值是内存压力模式开始对缓冲区使用应用压力的上限；第三个值是内存使用的上限。在这个层次上可以将报文丢弃，从而减少对内存的使用。对于较大的 BDP 可以增大这些值（注意：其单位是内存页而不是字节）  |
|  net.ipv4.tcp_rmem | 为自动调优定义 socket 使用的内存。第一个值是为 socket 接收缓冲区分配的最少字节数；第二个值是默认值（该值会被 rmem_default 覆盖），缓冲区在系统负载不重的情况下可以增长到这个值；第三个值是接收缓冲区空间的最大字节数（该值会被 rmem_max 覆盖）  |
|  net.ipv4.tcp_wmem |  为自动调优定义 socket 使用的内存。第一个值是为 socket 发送缓冲区分配的最少字节数；第二个值是默认值（该值会被 wmem_default 覆盖），缓冲区在系统负载不重的情况下可以增长到这个值；第三个值是发送缓冲区空间的最大字节数（该值会被 wmem_max 覆盖） |
| net.ipv4.tcp_keepalive_time  | TCP 发送 keepalive 探测消息的间隔时间（秒），用于确认 TCP 连接是否有效  |
| net.ipv4.tcp_keepalive_intvl  | 探测消息未获得响应时，重发该消息的间隔时间（秒）  |
|  net.ipv4.tcp_keepalive_probes | 在认定 TCP 连接失效之前，最多发送多少个 keepalive 探测消息  |
|  net.ipv4.tcp_sack | 启用有选择的应答（1 表示启用），通过有选择地应答乱序接收到的报文来提高性能，让发送者只发送丢失的报文段，（对于广域网通信来说）这个选项应该启用，但是会增加对 CPU 的占用  |
|net.ipv4.tcp_fack|启用转发应答，可以进行有选择应答（SACK）从而减少拥塞情况的发生，这个选项也应该启用|
|net.ipv4.tcp_timestamps|TCP 时间戳（会在 TCP 包头增加 12 B），以一种比重发超时更精确的方法（参考 RFC 1323）来启用对 RTT 的计算，为实现更好的性能应该启用这个选项|
|net.ipv4.tcp_window_scaling|启用 RFC 1323 定义的 window scaling，要支持超过 64KB 的 TCP 窗口，必须启用该值（1 表示启用），TCP 窗口最大至 1GB，TCP 连接双方都启用时才生效|
|net.ipv4.tcp_syncookies|表示是否打开 TCP 同步标签（syncookie），内核必须打开了 CONFIG_SYN_COOKIES 项进行编译，同步标签可以防止一个套接字在有过多试图连接到达时引起过载。默认值 0 表示关闭|
|net.ipv4.tcp_tw_reuse|表示是否允许将处于 TIME-WAIT 状态的 socket （TIME-WAIT 的端口）用于新的 TCP 连接|
|net.ipv4.tcp_tw_recycle|能够更快地回收 TIME-WAIT 套接字|
|net.ipv4.tcp_fin_timeout|对于本端断开的 socket 连接，TCP 保持在 FIN-WAIT-2 状态的时间（秒）。对方可能会断开连接或一直不结束连接或不可预料的进程死亡。|
|net.ipv4.ip_local_port_range|表示 TCP/UDP 协议允许使用的本地端口号|
|net.ipv4.tcp_max_syn_backlog|对于还未获得对方确认的连接请求，可保存在队列中的最大数目。如果服务器经常出现过载，可以尝试增加这个数字。默认为 1024|
|net.ipv4.tcp_low_latency|允许 TCP/IP 栈适应在高吞吐量情况下低延时的情况，这个选项应该禁用|
|net.ipv4.tcp_westwood|启用发送者端的拥塞控制算法，它可以维护对吞吐量的评估，并试图对带宽的整体利用情况进行优化，对于 WAN 通信来说应该启用这个选项|
|net.ipv4.tcp_bic|为快速长距离网络启用 Binary Increase Congestion，这样可以更好地利用以 GB 速度进行操作的链接，对于 WAN 通信应该启用这个选项|
|net.ipv4.tcp_max_tw_buckets|该参数设置系统的 TIME_WAIT 的数量，如果超过默认值则会被立即清除。默认为 180000|
|net.ipv4.tcp_synack_retries|指明了处于 SYN_RECV 状态时重传 SYN+ACK 包的次数|
|net.ipv4.tcp_abort_on_overflow|设置改参数为 1 时，当系统在短时间内收到了大量的请求，而相关的应用程序未能处理时，就会发送 Reset 包直接终止这些链接。建议通过优化应用程序的效率来提高处理能力，而不是简单地 Reset。默认值： 0|
|net.ipv4.route.max_size|内核所允许的最大路由数目|
|net.ipv4.ip_forward|接口间转发报文|
|net.ipv4.ip_default_ttl|报文可以经过的最大跳数|
|net.netfilter.nf_conntrack_tcp_timeout_established|让 iptables 对于已建立的连接，在设置时间内若没有活动，那么则清除掉|
|net.netfilter.nf_conntrack_max|哈希表项最大值|

* * *

参考：  
1.[https://help.aliyun.com/knowledge_detail/41334.html](https://help.aliyun.com/knowledge_detail/41334.html)   
2.[https://www.ibm.com/support/knowledgecenter/en/linuxonibm/liaag/wkvm/wkvm\_c\_tune_tcpip.htm](https://www.ibm.com/support/knowledgecenter/en/linuxonibm/liaag/wkvm/wkvm_c_tune_tcpip.htm)
