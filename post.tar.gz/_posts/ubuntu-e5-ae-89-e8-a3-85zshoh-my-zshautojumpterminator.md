---
title: 'ubuntu安装zsh,oh-my-zsh,autojump,terminator'
url: 407.html
id: 407
categories:
  - Linux
date: 2017-11-12 14:36:05
tags:
---

1.安装zsh,oh-my-zsh

    sudo apt-get install zsh git wget
    wget --no-check-certificate https://github.com/robbyrussell/oh-my-zsh/raw/master/tools/install.sh -O - | sh
    chsh -s /bin/zsh
    
    

注销重新进入后生效 2.安装autojump

    git clone git://github.com/joelthelion/autojump.git
    cd autojump
    sudo ./install.py
    . /home/hys/.autojump/etc/profile.d/autojump.sh #在~/.zshrc文件最后添加
    source ~/.zshrc
    
    重启终端后生效
    
    

或者直接通过软件仓库安装

    sudo apt-get install autojump
    
    . /usr/share/autojump/autojump.sh #在~/.zshrc文件最后添加
    
    source ~/.zshrc
    
    重启终端后生效
    
    

3.安装terminator

    sudo apt-get install terminator
    
    

安装oh-my-zsh可能会出现这样的错误 1.you may not change the shell for 'username'

    sudo usermod -s /bin/zsh username