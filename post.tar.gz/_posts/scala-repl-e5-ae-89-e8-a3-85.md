---
title: scala REPL安装
url: 1757.html
id: 1757
categories:
  - Scala
date: 2019-04-09 08:01:00
tags:
---

1.直接使用`apt-get`命令安装 `sudo apt-get install scala` 安装`scala`版本为`2.11.12`，却发现进入ＲＥＰＬ后，不能输入。 ２.直接[下载](https://www.scala-lang.org/download/)最新版本`2.12.8`二进制文件进行安装,解压，然后设置环境变量。 ３.输入`scala`,直接进入ＲＥＰＬ。 ![](http://hysyeah.top/wp-content/uploads/2019/04/scala_repl.png)