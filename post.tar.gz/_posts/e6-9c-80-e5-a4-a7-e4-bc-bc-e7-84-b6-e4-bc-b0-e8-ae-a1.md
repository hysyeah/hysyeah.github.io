---
title: 最大似然估计
url: 1207.html
id: 1207
categories:
  - 机器学习
date: 2018-06-26 10:38:19
tags:
---

若总体X属于离散型，其分布律\[latex\]P\\{X=x\\} = p(x;\\theta),\\theta \\in \\Theta\[/latex\]的形式为已知，\[latex\]\\theta\[/latex\]为待估参数，\[latex\]\\Theta\[/latex\]为\[latex\]\\theta\[/latex\]可能取值的范围。设\[latex\]X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n}\[/latex\]是来自X的样本，则\[latex\]X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n}\[/latex\]的联合分布律为  
\[latex\]\\prod_{i=1}^n p(x_{i};\\theta)\[/latex\] 又设\[latex\]x_{1},x_{2},\\cdot \\cdot \\cdot, x_{n}\[/latex\]是相应于样本\[latex\]X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n}\[/latex\]的一个样本值。易知样本\[latex\]X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n}\[/latex\]取到观察值\[latex\]x_{1},x_{2},\\cdot \\cdot \\cdot, x_{n}\[/latex\]的概率，亦即事件\[latex\]\\{ X_{1} = x_{1}, X_{2}=x_{2},\\cdot \\cdot \\cdot, X_{n}=x_{n}\\}\[/latex\]发生的概率为  
\[latex\]L(\\theta)=L(x_{1},x_{2},\\cdot \\cdot \\cdot,x_{n};\\theta) = \\prod_{i=1}^np(x_{i};\\theta), \\theta \\in \\Theta\[/latex\]  
这一概率随\[latex\]\\theta\[/latex\]的取值而变化，它是\[latex\]\\theta\[/latex\]的函数，\[latex\]L(\\theta)\[/latex\]称为样本的似然函数。  
最大似然估计法就是固定样本观察值\[latex\]x_{1},x_{2},\\cdot \\cdot \\cdot, x_{n}\[/latex\],在\[latex\]\\theta\[/latex\]的取值范围\[latex\]\\Theta\[/latex\]内挑选使似然函数\[latex\]L(x_{1},x_{2},\\cdot \\cdot \\cdot,x_{n};\\hat \\theta)=\\max_{\\theta \\in \\Theta}L(x_{1},x_{2},\\cdot \\cdot \\cdot,x_{n};\\theta)\[/latex\] 这样得到的\[latex\]\\hat \\theta\[/latex\]与样本值\[latex\]x_{1},x_{2},\\cdot \\cdot \\cdot, x_{n}\[/latex\]有关，常记为\[latex\]\\hat \\theta (x_{1},x_{2},\\cdot \\cdot \\cdot, x_{n})\[/latex\],称为参数\[latex\]\\theta\[/latex\]的最大似然估计值，而相应的统计量\[latex\]\\hat \\theta (X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n})\[/latex\]称为参数\[latex\]\\theta\[/latex\]的最大似然估计量。

* * *

若总体X属于连续型，其概率密度\[latex\]f(x;\\theta),\\theta \\in \\Theta\[/latex\]的形式为已知，\[latex\]\\theta\[/latex\]为待估参数，\[latex\]\\Theta\[/latex\]为\[latex\]\\theta\[/latex\]可能取值的范围。设\[latex\]X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n}\[/latex\]是来自X的样本，则\[latex\]X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n}\[/latex\]的联合密度为  
\[latex\]\\prod_{i=1}^n f(x_{i};\\theta)\[/latex\] 又设\[latex\]x_{1},x_{2},\\cdot \\cdot \\cdot, x_{n}\[/latex\]是相应于样本\[latex\]X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n}\[/latex\]的一个样本值，则随机点(\[latex\]X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n}\[/latex\])落在点\[latex\]x_{1},x_{2},\\cdot \\cdot \\cdot, x_{n}\[/latex\]的邻域(边长分别为\[latex\]dx_{1},dx_{2},\\cdot \\cdot \\cdot, dx_{n}\[/latex\]的n维立方体)内的概率近似的为  
\[latex\]\\prod_{i=1}^n f(x_{i};\\theta)dx_{i}\[/latex\]  
其值随\[latex\]\\theta\[/latex\]的取值而变化，与离散型的情况一样，我们取\[latex\] \\theta\[/latex\]估计值\[latex\]\\hat \\theta\[/latex\]使概率取到最大值，但因子\[latex\]\\prod_{i=1}^{n}dx_{i}\[/latex\]不随\[latex\]\\theta\[/latex\]而变，故只需考虑函数  
\[latex\]L(\\theta)=L(x_{1},x_{2},\\cdot \\cdot \\cdot,x_{n};\\theta) = \\prod_{i=1}^nf(x_{i};\\theta)\[/latex\]的最大值。  
若\[latex\]L(x_{1},x_{2},\\cdot \\cdot \\cdot,x_{n};\\hat \\theta)=\\max_{\\theta \\in \\Theta}L(x_{1},x_{2},\\cdot \\cdot \\cdot,x_{n};\\theta)\[/latex\]，则称\[latex\]\\hat \\theta (x_{1},x_{2},\\cdot \\cdot \\cdot, x_{n})\[/latex\]为\[latex\]\\theta\[/latex\]的最大似然估计值，称\[latex\]\\hat \\theta (X_{1},X_{2},\\cdot \\cdot \\cdot, X_{n})\[/latex\]称为参数\[latex\]\\theta\[/latex\]的最大似然估计量

* * *

例：设\[latex\]X \\sim b(1,p). X_{1},X_{2},\\cdot \\cdot \\cdot,X_{n}\[/latex\]是来自X的一个样本，试求参数p的最大似然估计值。  
![](http://hysyeah.top/wp-content/uploads/2018/06/max_likehood_example.jpg)

* * *

最大似然估计就是通过已知的样本点来求得求似然函数取值最大的参数\[latex\]\\theta\[/latex\],通常采用牛顿法和梯度下降法求解。 参考： 1.概率论与数理统计