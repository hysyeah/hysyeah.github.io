---
title: ubuntu常见dpkg错误
url: 1754.html
id: 1754
categories:
  - Linux
date: 2019-04-09 07:37:44
tags:
---

![](http://hysyeah.top/wp-content/uploads/2019/04/lock-frotend.png)

* * *

参考： １.[https://itsfoss.com/could-not-get-lock-error/](https://itsfoss.com/could-not-get-lock-error/)