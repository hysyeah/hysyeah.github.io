---
title: go get golang.org/x 包失败解决方法
url: 1533.html
id: 1533
categories:
  - GO
date: 2018-08-22 20:31:35
tags:
---

由于网络问题不能访问`golang.org`,通过go get安装golang官方包会失败，如

    go get lint
    package golang.org/x/lint: unrecognized import path "golang.org/x/lint" (https fetch: Get https://golang.org/x/lint?go-get=1: dial tcp 216.239.37.1:443: i/o timeout)
    

不翻墙的情况下怎么解决这个问题？其实 golang 在 github 上建立了一个镜像库，如 https://github.com/golang/lint 即是 https://golang.org/x/lint 的镜像库 解决方法

    mkdir -p $GOPATH/src/golang.org/x
    cd $GOPATH/src/golang.org/x
    git clone https://github.com/golang/lint.git
    

* * *

参考： 1.[https://blog.csdn.net/alexwoo0501/article/details/73409917](https://blog.csdn.net/alexwoo0501/article/details/73409917)