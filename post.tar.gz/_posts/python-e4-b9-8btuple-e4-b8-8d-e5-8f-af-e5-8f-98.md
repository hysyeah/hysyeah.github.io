---
title: python面试之tuple不可变
url: 1516.html
id: 1516
categories:
  - python
date: 2018-08-20 22:39:08
tags:
---

最近遇到个有关tuple的面试题，挺有意思的。

    # 下面会输出什么？为什么
    In [18]: tu = (1, [1, 2])
    In [19]: tu[1].append(3)
    In [20]: print(tu)
    (1, [1, 2, 3])
    
    

tupple不可变是指对象不可变，不可以对tuple中的元素进行赋值操作。它所包含的元素的可变性取决于该元素的属性。

    In [22]: tu[1] = [1,2,3]
    ---------------------------------------------------------------------------
    TypeError                                 Traceback (most recent call last)
    <ipython-input-22-1e2059dd0201> in <module>()
    ----> 1 tu[1] = [1,2,3]
    
    TypeError: 'tuple' object does not support item assignment
    
    

    In [24]: class A:
        ...:     a = 1
        ...:
    
    In [25]: a = A()
    In [28]: t = (1, a)
    
    In [29]: t[1].a = 2
    
    In [31]: print(t[1].a)
    2