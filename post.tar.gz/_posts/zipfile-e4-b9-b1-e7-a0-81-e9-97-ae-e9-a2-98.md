---
title: zipfile乱码问题
url: 915.html
id: 915
categories:
  - 未分类
date: 2018-05-31 17:49:53
tags:
---

python3.5使用zipfile.ZipFile("xx.zip")读取压缩文件为中文的文件时出现乱码 zipfile检测文件编码，如果是'utf-8'编码则解码为'utf-8',否则解码为'cp437',修改zipfile.py将'cp437'改为'gbk'即可。

    import zipfile
    import os
    os.path.dirname(zipfile.__file__)  #查看zipfile.py文件所在路径
    
    if flags & 0x800:
        # UTF-8 file names extension
        filename = filename.decode('utf-8')
    else:
        # Historical ZIP filename encoding
        filename = filename.decode('cp437')  #改为filename = filename.decode('gbk')
    
    if zinfo.flag_bits & 0x800:
        # UTF-8 filename
        fname_str = fname.decode("utf-8")
     else:
        fname_str = fname.decode("cp437")   #改为fname_str = fname.decode("gbk")
    
    

* * *

参考 1.[https://blog.csdn.net/tian544556/article/details/78635840](https://blog.csdn.net/tian544556/article/details/78635840)