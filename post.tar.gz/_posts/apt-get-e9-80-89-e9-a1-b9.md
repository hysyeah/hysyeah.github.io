---
title: apt-get选项
url: 249.html
id: 249
categories:
  - Linux
date: 2017-09-25 22:40:51
tags:
---

### 通过man apt-get查看

    --选项
    
    -d #只下载安装包
    
    -f #尝试修正系统依赖损坏处
    
    -m #忽略未找到的包
    
    -q #输出到日志 - 无进展指示
    
    -y #假定对所有的询问选是，不提示