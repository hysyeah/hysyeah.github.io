---
title: mysql shell 批量恢复
url: 1715.html
id: 1715
categories:
  - 数据库
date: 2019-03-20 19:29:17
tags:
---

有多个mysql的数据文件在文件夹在tmp文件夹下

    ls /root/tmp
    network.dump igw.dump vpn.dump vpc.dump
    

编写shell恢复数据

    #!/root/tmp
    for elt in $(ls *.dump)
    do
      echo "restore database $elt"
      mysql -uroot -pxxxxx ${elt%%.*} < $elt
    done