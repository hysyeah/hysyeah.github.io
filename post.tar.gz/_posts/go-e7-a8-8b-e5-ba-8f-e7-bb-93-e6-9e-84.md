---
title: Go程序结构
url: 1474.html
id: 1474
categories:
  - GO
date: 2018-08-13 09:52:48
tags:
---

Go 25个关键字

    break       default          func     interface   select
    case        defer            go       map         struct
    chan        else             goto     package     switch
    const       fallthrough      if       range       type
    continue    for              import   return      var
    

内置常量，类型，函数

    true        false       iota        nil
    

    int     int8    int16   int32   int64
    unit    uint8   unit16  unit32  uint64  unitptr
    float32     float64     complex128      complex64
    bool    byte    rune    string  error
    

    make    len     cap     new     append      copy    close   delete
    complex     real    imag
    panic   recover
    

如果一个名称是以大写字母开头的，表示此名称对于其它的package是可见和可获取的。

* * *

    // 常量a是package级别的声明，f是一个局部变量，package级别的实体是整个package可见的，不止在声明它的文件中。
    package main
    
    const a = 123;
    func main() {
        var f = a
    }
    

* * *

变量

    var name  type = expression
    
    var s string           //定义了一个名为s,类型为string的变量
    var i, j, k int        // int, int, int
    
    i := 100
    i, j: = 0, 1
    i, j = j, i            //交换变量
    

* * *

指针

    指针的"零值"是nil
    x := 1
    p := &x                        //通过&取变量x的地址
    
    函数返回一个局部变量的地址是安全，当函数返回后这个局部依然存在(在C语言中则会发生错误(段错误))
    func f() *int {
        v := 1
        return &v
    }
    
    func main() {
        fmt.Println(*f())    //1
    }
    
    //尽管x是局部变量，当函数返回后x还是可以被指针global访问，所以x必须分配在堆上，这种情况我们称为x逃离了f
    var global *int
    func f() {
        var x int
        x = 1
        global = &x
    }
    

赋值

    var s string = "hello"
    s := "hello"
    x, y := 0, 1
    
    m := make(map[string]int)
    v, ok = m[key]                  //返回两个值
    
    medals := []string{"hello", "world"}
    
    //定义一个map并初始化
    m3 := map[string]string{
        "a": "aa",
        "b": "bb",
    }
    

类型声明

    type name underlying-type
    
    type new_int int                        //给int定义一个别名new_int
    

作用域

    if f, err := os.Open(fname); err != nil { // compile error: unused: f
    return err
    }
    f.ReadByte() // compile error: undefined f
    f.Close() // compile error: undefined f
    
    //变量f的作用域只有在if语句内，因此后面的语句将无法引入它，这将导致编译错误
    

包的初始化

    包的初始化首先是解决包级变量的依赖顺序，然后安照包级变量声明出现的顺序依次初始
    化：
    var a = b + c // a 第三个初始化, 为 3
    var b = f() // b 第二个初始化, 为 2, 通过调用 f (依赖c)
    var c = 1 // c 第一个初始化, 为 1
    func f() int { return c + 1 }
    

    // init初始化函数除了不能被调用或引用外，其也行为和普通函数类似。在每个文件中的init初始化函数，在程序开始执行时按照它们声明的顺序被自动调用。
    func init() {  }
    

[相关代码](https://github.com/hys20151008/gopl/tree/master/src/ch2)

* * *

参考： 1.The Go Programming Language