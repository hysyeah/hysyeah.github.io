---
title: Django通过qq邮箱发送邮件
url: 279.html
id: 279
categories:
  - Django
date: 2017-09-27 12:43:42
tags:
---

通过Django的send\_mail发送邮件，send\_mail('subject', content, from\_mail,\['to\_mail'\]) 企业邮箱和普通邮箱所用的服务是不一样的，要区分开， 配置如下

    EMAIL_USE_TLS = True
    EMAIL_HOST = 'smtp.qq.com'  #若是企业邮箱要改为：'smtp.exmail.qq.com'
    EMAIL_PORT = 587
    EMAIL_HOST_USER = '12345678@qq.com'
    EMAIL_HOST_PASSWORD = 'xxxxxxxxxxxxxxxx'  #16位授权码(不是登录密码)，通过邮箱中的“设置”获取，可自行百度
    DEFAULT_FROM_EMAIL = '12345678@qq.com'