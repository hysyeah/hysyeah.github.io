---
title: 'super(Entity,self).__init__()'
url: 307.html
id: 307
categories:
  - python
date: 2017-10-02 15:17:30
tags:
---

    super(Entity,self).__init__()
    
    

这是对继承自父类的属性进行初始化。而且是用父类的初始化方法来初始化继承的属性。 也就是说，子类继承了父类的所有属性和方法，父类属性自然会用父类方法来进行初始化。当然，如果初始化的逻辑与父类的不同，不使用父类的方法，自己重新初始化也是可以的 和php中的parent::__construct()的作用应该是一样的。