---
title: mysql之ubuntu环境下安装
url: 1672.html
id: 1672
categories:
  - 数据库
date: 2019-02-19 22:57:15
tags:
---

##### 直接上命令

     sudo apt-get install mysql-server
     sudo apt-get install mysql-client
     sudo apt install libmysqlclient-dev   #客户端认证plugin需要依赖这个库
    

但是在这过程中没有提示设置密码。 在`/etc/mysql/`目录下有一个debian.cnf文件，文件中有一个系统分配的用户和密码。用户名为`debian-sys-maint`,通过这个用户就可以操作mysql了。

    可以新建一个root用户并对其进行授权,然后用新用户进行登录。
    
    create user 'root'@'%' ;
    grant all privileges on *.* to 'root'@'%' identified by 'hello';
    flush privileges;