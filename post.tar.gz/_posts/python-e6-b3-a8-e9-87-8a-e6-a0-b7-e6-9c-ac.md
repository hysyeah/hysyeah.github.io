---
title: python注释样本
url: 1288.html
id: 1288
categories:
  - python
date: 2018-07-10 20:24:00
tags:
---

    def select_proxy(url, proxies):
        """Select a proxy for the url, if applicable.
    
        :param url: The url being for the request  #参数
        :param proxies: A dictionary of schemes or schemes and hosts to proxy URLs
    
        :rtype: dict   #返回值
        """
    

    def twoSum(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[int]
        """