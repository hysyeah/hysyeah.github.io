---
title: 'python魔法变量之__init__,__del__'
url: 300.html
id: 300
categories:
  - python
date: 2017-10-02 13:15:46
tags:
---

**init**相当于构造函数，**del**相当于析构函数,而事实上**new**才是构造函数，**new**返回一个实例，而**init**则进行一些初始化工作。

    In [3]: class A(object):
    ...:        def __init__(self):
    ...:            print("init")
    ...:        def __del__(self):
    ...:            print("del")
    ...:
    
    In [4]: a = A()
    init
    
    In [5]: del a
    del