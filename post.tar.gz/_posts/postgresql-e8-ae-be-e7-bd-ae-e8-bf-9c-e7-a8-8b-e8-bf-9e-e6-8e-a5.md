---
title: postgresql设置远程连接
tags:
  - postgresql
url: 1861.html
id: 1861
categories:
  - 数据库
date: 2019-06-03 20:23:50
---

##### 1.vim /var/lib/pgsql/10/data/pg_hba.conf(文件所在的目录可能会不一样)

*   添加一行

    host    all     all     0.0.0.0/0       md5
    

##### 2.vim /var/lib/pgsql/data/postgresql.conf

`listen_addresses`修改为如下：

    listen_addresses = '*'
    

##### 3.重启服务

`pg_ctl restart`
