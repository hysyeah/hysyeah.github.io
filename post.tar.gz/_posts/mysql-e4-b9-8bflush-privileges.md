---
title: mysql之flush privileges
url: 1668.html
id: 1668
categories:
  - 数据库
date: 2019-02-19 07:53:08
tags:
---

    FLUSH PRIVILEGES # 重新从grant tables加载权限
    
    使用GRANT,CREATE USER, CREATE SERVER, INSTALL PLUGIN产生的缓存并不会因为使用对应的REVOKE, DROP USER, DROP SERVER, UNINSTALL PLUGIN而释放缓存。这些缓存可以通过调用FLUSH PRIVILEGES而释放。
    

##### GRANT TABLES IN MYSQL

    user: 用户帐户，全局权限
    db:   database级别的权限
    tables_priv: 表级别的权限
    columns_priv: 列级别的权限
    procs_priv:   存储过程和函数权限
    proxies_priv: 代理用户权限
    

* * *

参考： 1.[grant tables](https://dev.mysql.com/doc/refman/5.7/en/grant-tables.html) 2.[flush privileges](https://dev.mysql.com/doc/refman/5.7/en/flush.html#flush-privileges)