---
title: 'numpy,pandas安装'
url: 265.html
id: 265
categories:
  - python科学计算
date: 2017-09-27 06:49:46
tags:
---

    sudo apt-get install python3-tk
    pip3 install numpy
    pip3 install pandas
    pip3 intall matplotlib
    pip3 install scipy