---
title: lua -e
url: 232.html
id: 232
categories:
  - LUA
date: 2017-09-22 17:45:06
tags:
---

    lua -e "print("hello")" --ouput nil
    
    lua -e "print("1")" -- output 1
    
    

为什么lua -e "print("hello")"输出来nil, 而不是hello,这与shell的解析机制有关。 lua -e "print("hello")"相当于lua -e "print(hello)"("print" + hello + ")")，而hello未定义所以输出nil。 可以通过单引号禁止shell解析，或者使用转义符，

    lua -e 'print("hello")' -- output: hello
    lua -e "print(\"hello\")" -- output: hello