---
title: matplotlib subplot
url: 878.html
id: 878
categories:
  - python科学计算
date: 2018-05-16 23:13:30
tags:
---

![image](http://hysyeah.top/wp-content/uploads/2018/05/subplot.png)

#### 这两种方式是等价的