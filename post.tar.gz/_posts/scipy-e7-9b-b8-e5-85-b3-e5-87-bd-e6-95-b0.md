---
title: scipy相关函数
url: 1053.html
id: 1053
categories:
  - python科学计算
date: 2018-06-25 09:46:50
tags:
---

    scipy.special.expit                    # expit(x) = 1/(1+exp(-x))
    scipy.misc.derivative
    import scipy.integrate as integrate
    r = integrate.quad(lambda x: 2*x, 0,2) #函数f(x) = 2*x在区间[0,2]内的积分