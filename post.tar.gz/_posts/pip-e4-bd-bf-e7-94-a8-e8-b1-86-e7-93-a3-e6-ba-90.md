---
title: pip使用豆瓣源
url: 190.html
id: 190
categories:
  - 未分类
date: 2017-09-15 15:40:14
tags:
---

将pip源修改为豆瓣源 vim ~/.pip/pip.conf 没有则新建 添加如下内容: \[global\]

    index-url = http://pypi.douban.com/simple --trusted-host = pypi.douban.com
    

![image](http://hysyeah.top/wp-content/uploads/2017/09/douban.jpg) 2.临时更换

    sudo pip install pudb -i http://pypi.douban.com/simple --trusted-host=pypi.douban.com