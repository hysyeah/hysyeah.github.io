---
title: mysql之binlog-format
url: 1699.html
id: 1699
categories:
  - 数据库
date: 2019-03-09 14:27:08
tags:
---

`mysql`支持3种日志记录格式，`STATEMENT`,`ROW`,`MIXED` 可在启动时通过`--binlog_format=type`指定。

*   `STATEMENT`:也被称作logical logging,记录`mysql`执行的语句
*   `ROW`:也被称作physical logging,记录每行数据的变化
*   `MIXED`:即`STATEMENT`和`ROW`的混合形式，`mysql`会根据场景决定使用哪种日志格式

    # 查看目前使用的日志格式
    show variables like 'binlog_format';
    
    # 设置全局binlog_format，重新登录后生效
    SET GLOBAL binlog_format = 'STATEMENT';
    SET GLOBAL binlog_format = 'ROW';
    SET GLOBAL binlog_format = 'MIXED';
    
    # 设置会话级别的binlog_format
    SET SESSION binlog_format = 'STATEMENT';
    SET SESSION binlog_format = 'ROW';
    SET SESSION binlog_format = 'MIXED';
    
    
    

设置会话级别binlog\_format的几种情况： - 假如对数据库做了比较小的改动，可能会把binlog\_format设置为`ROW` \- 假如一次会话中在一条语句中更新了多行记录，此时使用`STATEMENT`可能会更高效 \- 有些语句可能执行需要的时间比较长，但结果只是几行数据被修改，这种情况也可以将binlog_format改为`ROW` 但一般不建议在运行时改变binlog\_format,下面几种不建议改变binlog\_format - 如果使用`NDB`存储引擎 \- 如果当前使用的是row-base replication而且存在临时表 当存在任何临时表时都不应该在运行时改变`binlog_format`,因为只有在`STATEMENT`的情况下日志才会记录临时的信息，而在`ROW`的格式下是不会记录的。在`MIXED`的模式下临时表通常也会记录。 每个mysql实例都可以设置自己的`binlog_format`，每个实例会以自己的`binlog_format`方式去解析日志文件，如果主从复制的架构中，master修改了`binlog_format`而slave没有修改，则会报错。为会确保改变`binlog_format`安全，需要停止复制并确保各个实例使用的是同一种日志格式。

* * *

参考： 1.[MYSQL Binary Log Format](https://dev.mysql.com/doc/refman/5.7/en/binary-log-setting.html)