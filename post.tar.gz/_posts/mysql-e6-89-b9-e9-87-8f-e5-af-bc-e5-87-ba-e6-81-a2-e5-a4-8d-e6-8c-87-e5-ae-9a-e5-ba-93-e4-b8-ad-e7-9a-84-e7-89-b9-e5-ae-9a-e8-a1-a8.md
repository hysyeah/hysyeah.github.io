---
title: mysql批量导出恢复指定库中的特定表
tags:
  - mysql
  - shell
url: 1766.html
id: 1766
categories:
  - Linux
date: 2019-04-11 07:09:45
---

目的：批量导出和恢复多个库中的特定表 1.先建立一个文件用于存储库名和表名 `cat databases.txt`

    # 每行第一个为库名，其余为表名，以英文逗号分隔
    portal,if_zone,uc_order,ecs_instance
    cdn,cdn_domain
    

2.编写dump脚本

    #!/bin/bash
    
    for elt in $(cat databases.txt)
    do
      echo "start dump $(echo $elt|cut -d \, -f 1)"
      mysqldump -hlocalhost -uroot -pxxxx --databases  $(echo $elt|cut -d \, -f 1) --tables $(echo $elt|cut -d \, -f 2- | sed 's/,/ /g') > $(echo $elt|cut -d \, -f 1).sql
      echo "done"
    done
    
    # cut -d \, -f 1       对输入字符以逗号进行切割，取第 一个
    # cut -d \, -f 2-      对输入字符以逗号进行切割，取第 二个到最后一个
    # sed 's/,/ /g'        将输入中的全部','替换为空格
    

3.编写restore脚本

    #!/bin/sh
    
    for elt in $(ls *.sql)
    do
      echo "start restore ${elt%%.*}"
      mysql -uroot -pxxxx -e "create database if not exists ${elt%%.*}"
      mysql -uroot -pxxxx ${elt%%.*} < $elt
      echo "done"
    done
    
    

#### 警示：在运行的系统中执行`mysqldump`命令，需考虑风险，因为`mysqldump`会有一些锁表的操作，详情详见下面参考中的链接。

* * *

参考： 1.[linux sed](http://hysyeah.top/2019/04/11/linux-sed/) 2.[linux cut](http://hysyeah.top/2019/04/11/linux-cut/) 3.[mysqldump](http://hysyeah.top/2019/04/12/mysqldump/)