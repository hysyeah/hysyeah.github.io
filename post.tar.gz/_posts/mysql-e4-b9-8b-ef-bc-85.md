---
title: mysql之％
url: 1681.html
id: 1681
categories:
  - 数据库
date: 2019-02-23 10:33:15
tags:
---

mysql在创建用户时可以指定host,通配符%表示可以匹配任何host(当然localhost除外，localhost优先级大于%)

    create user 'hys'@'%' identified by 'hello';
    create user 'hys'@'localhost' identified by 'wtf';
    create user 'hys'@'127.0.0.1' identified by '666';
    flush privileges;
    

![](http://hysyeah.top/wp-content/uploads/2019/02/mysqluser.png) 使用命令进行连接`mysql -uhys -phello`,报错如下 ![](http://hysyeah.top/wp-content/uploads/2019/02/mysqlacces.png) 使用命令进行连接`mysql -uhys -pwtf`则可以正常连接。 使用命令进行连接`mysql -uhys -h127.0.0.1 -p666` ![](http://hysyeah.top/wp-content/uploads/2019/02/mysqlacces.png) 说明mysql在进行连接时把`127.0.0.1`转换成了`localhost` 删除掉`hys@localhost` 使用命令进行连接`mysql -uhys -h127.0.0.1 -p666`可正常连接

* * *

结论： 1.通配符不包括`localhost` 2.当同一用户host同时存在`localhost`和`%`时，会优先匹配`localhost` 3.当同一用户host同时存在`localhost`和`127.0.0.1`时,虽然连接时指定了`-h127.0.0.1`但也会先匹配`localhost` 4.当存在`127.0.0.1`而不存在`localhost`，指定`-h127.0.0.1`可以进行连接

* * *

参考： ![](http://hysyeah.top/wp-content/uploads/2019/02/mysql.png) [https://dev.mysql.com/doc/mysql-security-excerpt/8.0/en/problems-connecting.html](https://dev.mysql.com/doc/mysql-security-excerpt/8.0/en/problems-connecting.html)