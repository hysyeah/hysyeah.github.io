---
title: 初识Dgraph
url: 1819.html
id: 1819
categories:
  - 数据库
date: 2019-05-19 15:45:57
tags:
---

1.Dgraph介绍 　关键字：快速，支持事务，分布式图数据库 ![](http://hysyeah.top/wp-content/uploads/2019/05/Screenshot-from-2019-05-19-15-17-10.png) ２.安装，启动Dgraph

    docker pull dgraph/dgraph:v0.7.7
    
    mkdir -p ~/dgraph
    docker run -it -p 127.0.0.1:8080:8080 -p 127.0.0.1:9080:9080 -v ~/dgraph:/dgraph --name dgraph dgraph/dgraph dgraph --bindall=true
    

3.访问`http://127.0.0.1:8080/` 4.在输入框中，分别输入如下数据，点击run

    mutation {
      set {
       _:luke <name> "Luke Skywalker" .
       _:leia <name> "Princess Leia" .
       _:han <name> "Han Solo" .
       _:lucas <name> "George Lucas" .
       _:irvin <name> "Irvin Kernshner" .
       _:richard <name> "Richard Marquand" .
    
       _:sw1 <name> "Star Wars: Episode IV - A New Hope" .
       _:sw1 <release_date> "1977-05-25" .
       _:sw1 <revenue> "775000000" .
       _:sw1 <running_time> "121" .
       _:sw1 <starring> _:luke .
       _:sw1 <starring> _:leia .
       _:sw1 <starring> _:han .
       _:sw1 <director> _:lucas .
    
       _:sw2 <name> "Star Wars: Episode V - The Empire Strikes Back" .
       _:sw2 <release_date> "1980-05-21" .
       _:sw2 <revenue> "534000000" .
       _:sw2 <running_time> "124" .
       _:sw2 <starring> _:luke .
       _:sw2 <starring> _:leia .
       _:sw2 <starring> _:han .
       _:sw2 <director> _:irvin .
    
       _:sw3 <name> "Star Wars: Episode VI - Return of the Jedi" .
       _:sw3 <release_date> "1983-05-25" .
       _:sw3 <revenue> "572000000" .
       _:sw3 <running_time> "131" .
       _:sw3 <starring> _:luke .
       _:sw3 <starring> _:leia .
       _:sw3 <starring> _:han .
       _:sw3 <director> _:richard .
    
       _:st1 <name> "Star Trek: The Motion Picture" .
       _:st1 <release_date> "1979-12-07" .
       _:st1 <revenue> "139000000" .
       _:st1 <running_time> "132" .
      }
    }
    

    mutation {
      schema {
        name: string @index .
        release_date: date @index .
        revenue: float .
        running_time: int .
      }
    }
    

5.查询数据,

    {
      me(func:allofterms(name, "Star Wars")) @filter(ge(release_date, "1980")) {
        name
        release_date
        revenue
        running_time
        director {
         name
        }
        starring {
         name
        }
      }
    }
    点击RUN
    

![](http://hysyeah.top/wp-content/uploads/2019/05/dgraph_pic.png)

* * *

总结：刚开始是安装的`dgraph/dgraph:v1.0.12`,但是启动后访问浏览器显示`disconneted`，为了快速看到浏览器中节点和关系的效果所以安装了`dgraph/dgraph:v0.7.7`。后续继续了解。

* * *

参考： 1.[https://yq.aliyun.com/articles/237205](https://yq.aliyun.com/articles/237205) 2.[https://docs.dgraph.io/get-started/#dataset](https://yq.aliyun.com/articles/237205)