---
title: postgreql元数据相关SQL
tags:
  - postgresql
url: 1845.html
id: 1845
categories:
  - 数据库
date: 2019-06-01 14:42:17
---

    # 查看schemas
    SELECT schema_name FROM information_schema.schemata;
    SELECT nspname FROM pg_catalog.pg_namespace;
    

    # 查看连接状态
    SELECT * FROM pg_stat_activity;
    
    # kill 连接数据库ptldwh的所有session
    SELECT pg_terminate_backend(a.pid) FROM pg_stat_activity a WHERE datname='ptldwh';