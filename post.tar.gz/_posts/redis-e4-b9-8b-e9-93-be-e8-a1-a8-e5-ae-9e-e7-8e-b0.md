---
title: redis之链表实现
url: 1448.html
id: 1448
categories:
  - Redis
date: 2018-08-11 00:20:11
tags:
---

Redis链表的实现代码在src/\[adlist.h, adlist.c\]

    typedef struct listNode {
        // 指向前节点的指针
        struct listNode *prev;
    
        // 指向后节点的指针
        struct listNode *next;
    
        // 节点的值
        void *value;
    
    } listNode;
    

![](http://hysyeah.top/wp-content/uploads/2018/08/dualist.png)

    typedef struct list {
    
        // 表头节点
        listNode *head;
    
        // 表尾节点
        listNode *tail;
    
        // 节点值复制函数
        void *(*dup)(void *ptr);
    
        // 节点值释放函数
        void (*free)(void *ptr);
    
        // 节点值对比函数
        int (*match)(void *ptr, void *key);
    
        // 链表所包含的节点数量
        unsigned long len;
    
    } list;
    

![](http://hysyeah.top/wp-content/uploads/2018/08/adlist.png)

    // 返回给定链表所包含的节点数量
    // T = O(1)
    #define listLength(l) ((l)->len)
    // 返回给定链表的表头节点
    // T = O(1)
    #define listFirst(l) ((l)->head)
    // 返回给定链表的表尾节点
    // T = O(1)
    #define listLast(l) ((l)->tail)
    // 返回给定节点的前置节点
    // T = O(1)
    #define listPrevNode(n) ((n)->prev)
    // 返回给定节点的后置节点
    // T = O(1)
    #define listNextNode(n) ((n)->next)
    // 返回给定节点的值
    // T = O(1)
    #define listNodeValue(n) ((n)->value)
    
    // 将链表 l 的值复制函数设置为 m
    // T = O(1)
    #define listSetDupMethod(l,m) ((l)->dup = (m))
    // 将链表 l 的值释放函数设置为 m
    // T = O(1)
    #define listSetFreeMethod(l,m) ((l)->free = (m))
    // 将链表的对比函数设置为 m
    // T = O(1)
    #define listSetMatchMethod(l,m) ((l)->match = (m))
    
    // 返回给定链表的值复制函数
    // T = O(1)
    #define listGetDupMethod(l) ((l)->dup)
    // 返回给定链表的值释放函数
    // T = O(1)
    #define listGetFree(l) ((l)->free)
    // 返回给定链表的值对比函数
    // T = O(1)
    #define listGetMatchMethod(l) ((l)->match)
    

    // 创建一个新的链表
    list *listCreate(void)
    {
        struct list *list;
    
        // 分配内存
        if ((list = zmalloc(sizeof(*list))) == NULL)
            return NULL;
    
        // 初始化属性
        list->head = list->tail = NULL;
        list->len = 0;
        list->dup = NULL;
        list->free = NULL;
        list->match = NULL;
    
        return list;
    }
    

    /*
     * 释放整个链表，以及链表中所有节点
     *
     * T = O(N)
     */
    void listRelease(list *list)
    {
        unsigned long len;
        listNode *current, *next;
    
        // 指向头指针
        current = list->head;
        // 遍历整个链表
        len = list->len;
        while(len--) {
            next = current->next;
    
            // 如果有设置值释放函数，那么调用它
            if (list->free) list->free(current->value);
    
            // 释放节点结构
            zfree(current);
    
            current = next;
        }
    
        // 释放链表结构
        zfree(list);
    }
    

    /*
     * 将一个包含有给定值指针 value 的新节点添加到链表的表头
     *
     * 如果为新节点分配内存出错，那么不执行任何动作，仅返回 NULL
     *
     * 如果执行成功，返回传入的链表指针
     *
     * T = O(1)
     */
    list *listAddNodeHead(list *list, void *value)
    {
        listNode *node;
    
        // 为节点分配内存
        if ((node = zmalloc(sizeof(*node))) == NULL)
            return NULL;
    
        // 保存值指针
        node->value = value;
    
        // 添加节点到空链表
        if (list->len == 0) {
            list->head = list->tail = node;
            node->prev = node->next = NULL;
        // 添加节点到非空链表
        } else {
            node->prev = NULL;          //新节点前驱置为NULL
            node->next = list->head;    //新节点的后驱置为头节点
            list->head->prev = node;    //头结点的前驱更新为node节点
            list->head = node;          //头结点更新为node节点
        }
    
        // 更新链表节点数
        list->len++;
    
        return list;
    }
    

    /*
     * 将一个包含有给定值指针 value 的新节点添加到链表的表尾
     *
     * 如果为新节点分配内存出错，那么不执行任何动作，仅返回 NULL
     *
     * 如果执行成功，返回传入的链表指针
     *
     * T = O(1)
     */
    list *listAddNodeTail(list *list, void *value)
    {
        listNode *node;
    
        // 为新节点分配内存
        if ((node = zmalloc(sizeof(*node))) == NULL)
            return NULL;
    
        // 保存值指针
        node->value = value;
    
        // 目标链表为空
        if (list->len == 0) {
            list->head = list->tail = node;
            node->prev = node->next = NULL;
        // 目标链表非空
        } else {
            node->prev = list->tail;    //node节点前驱为尾结点
            node->next = NULL;          //node节点后驱置为NULL
            list->tail->next = node;    //尾结点的后驱更新为node结点
            list->tail = node;          //尾结点更新为node结点
        }
    
        // 更新链表节点数
        list->len++;
    
        return list;
    }
    

    /*
     * 创建一个包含值 value 的新节点，并将它插入到 old_node 的之前或之后
     *
     * 如果 after 为 0 ，将新节点插入到 old_node 之前。
     * 如果 after 为 1 ，将新节点插入到 old_node 之后。
     *
     * T = O(1)
     */
    list *listInsertNode(list *list, listNode *old_node, void *value, int after) {
        listNode *node;
    
        // 创建新节点
        if ((node = zmalloc(sizeof(*node))) == NULL)
            return NULL;
    
        // 保存值
        node->value = value;
    
        // 将新节点添加到给定节点之后
        if (after) {
            node->prev = old_node;
            node->next = old_node->next;
            // 给定节点是原表尾节点
            if (list->tail == old_node) {
                list->tail = node;
            }
        // 将新节点添加到给定节点之前
        } else {
            node->next = old_node;
            node->prev = old_node->prev;
            // 给定节点是原表头节点
            if (list->head == old_node) {
                list->head = node;
            }
        }
    
        // 更新新节点的前置指针
        if (node->prev != NULL) {
            node->prev->next = node;
        }
        // 更新新节点的后置指针
        if (node->next != NULL) {
            node->next->prev = node;
        }
    
        // 更新链表节点数
        list->len++;
    
        return list;
    }
    

    /*
     * 取出链表的表尾节点，并将它移动到表头，成为新的表头节点。
     *
     * T = O(1)
     */
    void listRotate(list *list) {
        listNode *tail = list->tail;// 取出表尾节点
    
        if (listLength(list) <= 1) return;
    
        /* Detach current tail */
    
        list->tail = tail->prev; //尾结点为先尾结点的前一个结点
        list->tail->next = NULL; //新尾结点指向NULL
    
        /* Move it as head */
        // 插入到表头
        list->head->prev = tail; //旧头结点的前驱变为旧尾结点
        tail->prev = NULL;       //旧尾结点的前驱置为NULL
        tail->next = list->head; //旧尾结点的后驱置为头结点
        list->head = tail;       //新头结点置为旧尾结点
    }
    

    /*
     * 从链表 list 中删除给定节点 node 
     * 
     * 对节点私有值(private value of the node)的释放工作由调用者进行。
     *
     * T = O(1)
     */
    void listDelNode(list *list, listNode *node)
    {
        // 调整前置节点的指针
        if (node->prev)
            node->prev->next = node->next;
        else
            list->head = node->next;
    
        // 调整后置节点的指针
        if (node->next)
            node->next->prev = node->prev;
        else
            list->tail = node->prev;
    
        // 释放值
        if (list->free) list->free(node->value);
    
        // 释放节点
        zfree(node);
    
        // 链表数减一
        list->len--;
    }
    

    // 为给定链表创建一个迭代器，之后每次对这个迭代器调用 listNext 都返回被迭代到的链表节点
    listIter *listGetIterator(list *list, int direction)
    {
        // 为迭代器分配内存
        listIter *iter;
        if ((iter = zmalloc(sizeof(*iter))) == NULL) return NULL;
    
        // 根据迭代方向，设置迭代器的起始节点
        if (direction == AL_START_HEAD)
            iter->next = list->head;
        else
            iter->next = list->tail;
    
        // 记录迭代方向
        iter->direction = direction;
    
        return iter;
    }
    

    // 返回迭代器当前所指向的节点
    listNode *listNext(listIter *iter)
    {
        listNode *current = iter->next;
    
        if (current != NULL) {
            // 根据方向选择下一个节点
            if (iter->direction == AL_START_HEAD)
                // 保存下一个节点，防止当前节点被删除而造成指针丢失
                iter->next = current->next;
            else
                // 保存下一个节点，防止当前节点被删除而造成指针丢失
                iter->next = current->prev;
        }
    
        return current;
    }
    

    listNode *listSearchKey(list *list, void *key)
    {
        listIter *iter;
        listNode *node;
    
        // 迭代整个链表
        iter = listGetIterator(list, AL_START_HEAD);
        while((node = listNext(iter)) != NULL) {
    
            // 对比
            if (list->match) {
                if (list->match(node->value, key)) {
                    listReleaseIterator(iter);
                    // 找到
                    return node;
                }
            } else {
                if (key == node->value) {
                    listReleaseIterator(iter);
                    // 找到
                    return node;
                }
            }
        }
    
        listReleaseIterator(iter);
    
        // 未找到
        return NULL;
    }
    

[测试代码](https://github.com/hys20151008/datastructures/blob/master/adlist.c)

* * *

参考： 1.Redis设计与实现 2.Redis源码