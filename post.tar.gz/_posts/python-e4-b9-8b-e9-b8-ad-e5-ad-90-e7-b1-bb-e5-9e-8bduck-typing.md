---
title: python之鸭子类型(Duck typing)
url: 1574.html
id: 1574
categories:
  - python
date: 2018-09-08 16:48:32
tags:
---

"如果它像鸭子一样走路，它像鸭子一样呱呱叫，那它一定是鸭子" \- 以确定一个物体是否可以用于特定目的。 在duck typing中，对象的适用性取决于某些方法和属性的存在，而不是对象本身的类型。我们并不关心对象是什么类型，到底是不是鸭子，只关心行为。

    class Duck:
        def fly(self):
            print("Duck flying")
    
    class Airplane:
        def fly(self):
            print("Airplane flying")
    
    class Whale:
        def swim(self):
            print("Whale swimming")
    
    def lift_off(entity):
        entity.fly()
    
    duck = Duck()
    airplane = Airplane()
    whale = Whale()
    
    lift_off(duck) # prints `Duck flying`
    lift_off(airplane) # prints `Airplane flying`
    lift_off(whale) # Throws the error `'Whale' object has no attribute 'fly'
    
    # 在lift_off函数中我们并不关心传入的参数是什么类型，只关心这个对象拥有什么方法。
    

比如在python中，有很多file-like的东西，比如StringIO,GzipFile,socket。它们有很多相同的方法，我们把它们当作文件使用。 再如只要一个类实现了`__iter__`方法，我们就说这个对象是可迭代的。

    In [1]: class A:
       ...:     def __iter__(self):
       ...:         pass
       ...:
    
    In [2]: a = A()
    
    In [3]: from collections import Iterable
    
    In [4]: isinstance(a, Iterable)
    Out[4]: True
    

* * *

参考： 1.[wikipedia](https://en.wikipedia.org/wiki/Duck_typing) 2.[csdn](https://blog.csdn.net/handsomekang/article/details/40270009)