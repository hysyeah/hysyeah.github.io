---
title: hello-world
date: 2017-08-25 00:44:10
tags:
---

```
print("hello world")
```
