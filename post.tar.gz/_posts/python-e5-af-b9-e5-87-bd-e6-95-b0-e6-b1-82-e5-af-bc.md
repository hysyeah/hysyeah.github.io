---
title: python对函数求导
url: 859.html
id: 859
categories:
  - 未分类
date: 2018-05-16 11:16:24
tags:
---

假设函数\[latex\]f(x) = x^3+2x\[/latex\],求\[latex\]f'(x)\[/latex\]在x=1的值. 1.通过numpy多项式求导

    import numpy as np
    y = np.poly1d([1,0,2,0])
    

    print(y)         # 3*x**2 + 2*x       
    

    dy = y.deriv()
    dy(1)                         # 5
    
    

2.通过sympy对函数求导,通过命令pip3 install sympy安装

    from sympy import symbols
    from sympy import diff as diff
    from npmath import diff as diff2
    
    x = symbols('x')
    f = x**3 + 2*x
    f1 = diff(f)
    print(f1)              # 3*x**2 + 2
    
    diff2(lambda x: x**3+2*x,1)         # 5
    

* * *

参考： 1.[sympy文档](http://docs.sympy.org/latest/tutorial/calculus.html) 2.[mpmath文档](http://mpmath.org/doc/1.0.0/calculus/differentiation.html?highlight=diff#mpmath.diff)