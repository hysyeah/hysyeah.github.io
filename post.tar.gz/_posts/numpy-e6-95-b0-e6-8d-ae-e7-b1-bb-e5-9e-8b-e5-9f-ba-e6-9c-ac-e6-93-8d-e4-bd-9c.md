---
title: numpy数据类型基本操作
url: 58.html
id: 58
categories:
  - python科学计算
date: 2017-09-05 22:57:53
tags:
---

1.导入numpy包，调用array()函数创建一维数组

    In [3]: import numpy as np
    
    In [4]: a = np.array(range(6))
    
    In [5]: a
    Out[5]: array([0, 1, 2, 3, 4, 5])
    
    In [6]: print(a)
    [0 1 2 3 4 5]
    
    

2.array的shape属性

    In [7]: a.shape
    Out[7]: (6,)
    
    In [8]: a.shape = 2, 3
    
    In [9]: a
    Out[9]:
    array([[0, 1, 2],
    [3, 4, 5]])
    
    

3.通过reshape()函数在a的基础上创建一个新的二维结构的数组a1,a的shape属性值不会变

    In [17]: a1 = a.reshape(3,2)
    
    In [18]: print(a1)
    [[0 1]
    [2 3]
    [4 5]]
    
    In [19]: a1.shape
    Out[19]: (3, 2)
    
    In [20]: a.shape
    Out[20]: (2, 3)
    
    

数组a和a1共用内存中的数据存储值，若更改其中任意一个数组中的元素值，则另一个相对应的元素也会改变。

    In [23]: print(a1)
    [[0 1]
    [2 3]
    [4 5]]
    
    In [24]: a[1, 2] = 88
    
    In [25]: print(a1)
    [[ 0 1]
    [ 2 3]
    [ 4 88]]
    
    

4.利用arange(\[start,\] stop\[, step,\], dtype=None)函数生成数组

    In [2]: a = np.arange(13, 1, -1)
    
    In [3]: print(a)
    [13 12 11 10 9 8 7 6 5 4 3 2]
    
    

5.利用linspace(start, stop, num=50, endpoint=True, retstep=False, dtype=None)函数生成数组

    In [9]: a = np.linspace(1, 12, 12)
    
    In [10]: print(a)
    [ 1. 2. 3. 4. 5. 6. 7. 8. 9. 10. 11. 12.]
    
    In [11]: a.dtype
    Out[11]: dtype('float64')
    
    

6.常用函数

    zeros(shape, dtype=float, order='C')生成元素全部为0的数组
    
    ones(shape, dtype=None, order='C')生成元素全部为1的数组
    
    empty(shape, dtype=float, order='C')生成给定维度无初始值的数组