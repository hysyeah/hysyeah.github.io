---
title: lua变量类型
url: 263.html
id: 263
categories:
  - LUA
date: 2017-09-27 07:14:25
tags:
---

lua是动态语言，变量不需要定义。lua中有8个基本类型：nil, bollean, number, string, userdata, thread和table.

    Lua 5.3.4  Copyright (C) 1994-2017 Lua.org, PUC-Rio
    > print(type("hello, lua"))
    string
    > print(type(10))
    number
    > print(type(print))
    function
    > print(type(true))
    boolean
    > print(type(nil))
    nil
    

1.nil nil是lua中的特殊值，它只有一个值;变量未赋值前值为nil,可以通过给变量赋值为nil,删除变量 2.Booleans Booleans类型有两个值：false和true。Lua中所有的值都可以做为判断条件。在控制结构中的条件判断中除了false和nil为假，其它值都为真，也就是说Lua中0和空字符串也是真。 3.Numbers Numbers表示实数，Lua中没有整数。 4.Strings 字符串，Lua中字符串是不可修改的。Lua自动进行内存分配和释放，一个string可以只包含一个字母也可以包含一本书，Lua可以高效的处理长字符串，1M的string在Lua中是很常见的。可以使用单引号或者双引号表示字符串。

    > a = "one string"
    > b = string.gsub(a, "one", "another")
    > print(a)
    one string
    > print(b)
    another string
    
    

可以使用\[\[...\]\]表示字符串，这种 形式的字符串可以包括多行，可以嵌套且不会解释转义序列。 Lua会自动在string和numbers 之间自动进行类型转换，当一个字符串使用算术操作符时，string就会被转成数字。

    > print("10"+1)
    11.0
    
    > print("10+1")
    10+1
    
    

当Lua期望一个string而碰到数字时，会将数字转成string。如进行字符拼接时

    > print(10 .. 20)
    1020
    > 10 == "10"
    false
    

5.Functions(函数) 函数是第一类值（和其他变量相同），意味着函数可以存储在变量中，可以作为函数的参数，也可以作为函数的返回值。