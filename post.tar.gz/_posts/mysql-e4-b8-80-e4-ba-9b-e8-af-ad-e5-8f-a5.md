---
title: mysql一些语句
url: 337.html
id: 337
categories:
  - 数据库
date: 2017-10-28 08:14:36
tags:
---

### 获取一张表的所有字段名

    select COLUMN_NAME from information_schema.columns where table_name='TableName'
    

### 对一个数据库进行赋权

    grant all privileges on database.* to username@ip identified by 'passwd'
    flush privileges