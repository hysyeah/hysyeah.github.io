---
title: 将图像转换为excel表格
url: 1105.html
id: 1105
categories:
  - 未分类
date: 2018-06-15 17:14:49
tags:
---

原理：将图像中的每一个点映射到excel中的每一个单元格 安装：PIL, openpyxl 步骤： 1.使用PIL读取图像 2.使用openpyxl将一个个像素点写入到excel文件 中

    # -*- coding: utf-8 -*-
    # 将图像转换为excel文件，一个像素点对应一个单元格
    import re
    import openpyxl
    from PIL import Image
    from openpyxl.styles import PatternFill
    
    # 因为通过PIL获取到的像素点是元组，所以将元组转换为FFEEFFDD格式的字符串
    def tuple2str(t):
        lst = ['{0:#0{1}x}'.format(elt, 4) for elt in t]
        s = ''.join(lst)
        return re.sub('0x', '', s).upper()
    
    # 设置填充的颜色
    def fill_color(s):
        color = PatternFill(fgColor=s, bgColor='00000000',fill_type='solid')
        return color
    
    wb = openpyxl.Workbook()
    ws = wb.active
    
    im = Image.open('t.jpg')
    # 循环将像素点写入excel
    for i in range(0,im.size[-1]):
        for j in range(0,im.size[0]):
            pixel = im.getpixel((j,i))
            pixel_str = tuple2str(pixel)
            print(i,j,pixel_str)
            color = fill_color(pixel_str)
            d = ws.cell(row=i+1, column=j+1)
            d.fill = color
    
    for col in ws.columns:
        column = col[0].column
        ws.column_dimensions[column].width=1
    
    for row in ws.rows:
        row = row[0].row
        ws.row_dimensions[row].height=1
    wb.save('out.xlsx')
    

[完整代码](https://github.com/hys20151008/7788/blob/master/image2excel.py)

* * *

输入图像为： ![](http://hysyeah.top/wp-content/uploads/2018/06/img2excel.jpg) 输出excel: ![](http://hysyeah.top/wp-content/uploads/2018/06/excelimg.png)

* * *

参考： 一则新闻