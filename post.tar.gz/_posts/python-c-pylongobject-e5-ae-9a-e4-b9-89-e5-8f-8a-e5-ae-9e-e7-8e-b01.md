---
title: python c  PyLongObject定义及实现1
url: 611.html
id: 611
categories:
  - python源码
date: 2017-12-12 23:32:18
tags:
---

    typedef PY_UINT32_T digit;
    #define PyObject_VAR_HEAD               \
        PyObject_HEAD                       \
        Py_ssize_t ob_size;
    
    struct _longobject {
        PyObject_VAR_HEAD
        digit ob_digit[1];
    };
    typedef struct _longobject PyLongObject;
    

PyLongObject对象除了引用计数ob\_refcnt,*ob\_type指针，与PyIntObject不同的是，通过动态改变ob_digit数组的大小，以实现任意精度的长整形。 PyLongObject对象的绝对值表示为

    SUM(for i=0 through abs(ob_size)-1) ob_digit[i] * 2**(SHIFT*i)
    

当数值为0L时，ob\_size = 0，不会为ob\_digit数组分配内存。 当数值为负数时，ob\_size < 0; 当创建一个PyLongObject时，内存分配函数会为ob\_digit数组分配足够的空间，所以ob\_digit\[0\] ... ob\_digit\[abs(ob_size)-1\]是有效的。 [为结构体的成员数组动态分配大小](http://hysyeah.top/2017/12/12/%E4%B8%BA%E7%BB%93%E6%9E%84%E4%BD%93%E7%9A%84%E6%88%90%E5%91%98%E6%95%B0%E7%BB%84%E5%8A%A8%E6%80%81%E5%88%86%E9%85%8D%E5%A4%A7%E5%B0%8F/)