---
title: pandas数据类型Series及基本操作
url: 60.html
id: 60
categories:
  - python科学计算
date: 2017-08-30 07:53:24
tags:
---

Series类型的数据由一列数据及与之对应的标签（索引，位于数据的左侧）两部分组成。Series对象本质上 是一个NumPy数组，因此NumPy的数组处理函数同样适用于Series对象。每个Series对象都具有index和values 两大属性。 - index:保存标签信息 - values:保存值 1.创建Series对象

    In [1]: import pandas as pd
    
    In [2]: import numpy as np
    
    In [3]: s1 = pd.Series()
    
    In [4]: s1
    Out[4]: Series([], dtype: float64)
    

2.Series对象的访问

    In [8]: s2 = pd.Series([1, 3, 5, 7, 9], index=['a', 'b', 'c', 'd', 'e'])
    
    In [9]: s2
    Out[9]: 
    a    1
    b    3
    c    5
    d    7
    e    9
    dtype: int64
    
    In [10]: s2.values
    Out[10]: array([1, 3, 5, 7, 9])
    
    In [11]: s2.index
    Out[11]: Index(['a', 'b', 'c', 'd', 'e'], dtype='object')
    
    In [12]: s2['e']
    Out[12]: 9
    
    

3.添加新元素

    In [13]: s2['f'] = 66
    
    In [14]: s2
    Out[14]: 
    a     1
    b     3
    c     5
    d     7
    e     9
    f    66
    dtype: int64
    

4.将字典对象转换为Series对象

    In [15]: pd.Series({'a': 1, 'b': 2, 'c': 3})
    Out[15]: 
    a    1
    b    2
    c    3
    dtype: int64
    

5.Series对象的元素提取与切片

    obj.head(n=5) #默认查看对象的前五个数据
    obj.tail(n=5) #默认查看对象最后五个数据
    obj.take()    #通过传入索引值列表来提取元素
    
    In [18]: s2.head()
    Out[18]: 
    a    1
    b    3
    c    5
    d    7
    e    9
    dtype: int64
    
    In [19]: s2.tail()
    Out[19]: 
    c     5
    d     7
    e     9
    f    66
    g    11
    dtype: int64
    
    In [20]: s2.take([2, 4, 0]) #指定索引值
    Out[20]: 
    c    5
    e    9
    a    1
    dtype: int64
    

6.切片

    In [22]: s2[0:4] #位置切片，不包括结束位置
    Out[22]: 
    a    1
    b    3
    c    5
    d    7
    dtype: int64
    
    In [23]: s2['a':'d'] #标签切片，包括结束位置
    Out[23]: 
    a    1
    b    3
    c    5
    d    7
    dtype: int64
    

7.时间序列 Timestamp对象由Pandas包中的Timestamp()来创建，参数可以为str类型，也可以为datetime类型。

    In [28]: date
    Out[28]: datetime.datetime(2017, 9, 16, 0, 0)
    
    In [29]: date = pd.Timestamp(date)
    
    In [30]: date
    Out[30]: Timestamp('2017-09-16 00:00:00')
    

通过to_datetime()将Series的index属性转换为DatetimeIndex(实际上对于datetime对象，我们可以直接 将其作为index，Pandas会自动将其转换成Timestamp对象

    In [31]: dates = ['2017-01-01', '2017-01-02', '2017-01-03']
    
    In [32]: ts = pd.Series([1, 2, 3], index=pd.to_datetime(dates))
    
    In [33]: ts
    Out[33]: 
    2017-01-01    1
    2017-01-02    2
    2017-01-03    3
    dtype: int64
    
    In [34]: ts.index
    Out[34]: DatetimeIndex(['2017-01-01', '2017-01-02', '2017-01-03'], dtype='datetime64[ns]', freq=None)
    
    

8.截取时间段数据

    In [35]: ts['20170101']
    Out[35]: 1
    
    In [36]: ts['2017-01-01']
    Out[36]: 1
    
    In [37]: ts['01/01/2017']
    Out[37]: 1
    
    In [38]: ts['2017']
    Out[38]: 
    2017-01-01    1
    2017-01-02    2
    2017-01-03    3
    dtype: int64
    
    In [39]: ts['2017-01': '2017-02']
    Out[39]: 
    2017-01-01    1
    2017-01-02    2
    2017-01-03    3
    dtype: int64
    
    In [41]: ts.truncate(after='2017-01-02')
    Out[41]: 
    2017-01-01    1
    2017-01-02    2
    dtype: int64
    

9.滞后或者超前操作

    In [43]: ts.shift(1) #正数为滞后
    Out[43]: 
    2017-01-01    NaN   #2017-01-01的数据为前一项的数据，但前一项没有数据所以为NaN
    2017-01-02    1.0   # 2017-01-02数据为2017-01-01的数据，所以为1
    2017-01-03    2.0
    dtype: float64
    

    In [44]: ts.shift(-1)  #负数为超前
    Out[44]: 
    2017-01-01    2.0
    2017-01-02    3.0
    2017-01-03    NaN
    dtype: float64
    

10.计算收益率

    In [45]: (ts - ts.shift(1))/ts.shift(1)
    Out[45]: 
    2017-01-01    NaN
    2017-01-02    1.0
    2017-01-03    0.5
    dtype: float64
    

    In [124]: a = pd.Series(['a','a','b','c'])
    
    In [125]: a.value_counts()
    Out[125]:
    a    2
    b    1
    c    1
    dtype: int64