---
title: docker-compose up -d启动失败不能创建网络
url: 666.html
id: 666
categories:
  - 未分类
date: 2018-02-01 11:29:59
tags:
---

    当修改docker-compose.yml文件后台，使用命令docker-coompose up -d 启动服务
    出现如下错误
    Creating network "master_sparknet" with driver "bridge"
    ERROR: cannot create network ddc16ca081602776df238912eeb042380f5cb15b88c108799b66d074742c704a (br-ddc16ca08160): conflicts with network fa6a55dd5ed30ce92342c4d3218558139293fd1800f5893c83b9f6a75aeaf277 (br-fa6a55dd5ed3): networks have overlapping IPv4
    
    提示不能创建网络，两个网络发生冲突
    

##### 解决方法

    1.docker network ls  #展示docker容器网络
    2.找到冲突的网络 docker network rm fa6a55dd5ed3
    3.docker-compose up -d #重新启动服务