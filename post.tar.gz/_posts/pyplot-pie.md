---
title: pyplot.pie
url: 433.html
id: 433
categories:
  - pyplot
  - python科学计算
date: 2017-11-27 19:43:09
tags:
---

matplotlib.pyplot.pie(x, explode=None, labels=None, colors=None, autopct=None, pctdistance=0.6, shadow=False, labeldistance=1.1, startangle=None, radius=None, counterclock=True, wedgeprops=None, textprops=None, center=(0, 0), frame=False, hold=None, data=None) 根据数组x绘制饼图 explode:数组扇形离圆点的距离(爆炸出来的那部分) labels:标题 colors:颜色 autopct:饼图扇区面积所显示的文字 shadow:阴影 startangle: title:图标题

* * *

    import matplotlib.pyplot as plt
    
    # Pie chart, where the slices will be ordered and plotted counter-clockwise:
    labels = 'Frogs', 'Hogs', 'Dogs', 'Logs'
    sizes = [15, 30, 45, 10]
    explode = (0, 0.1, 0, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')
    
    fig1, ax1 = plt.subplots()
    ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%',
            shadow=True, startangle=90) #autopct 扇形区域显示的文字格式
    ax1.axis("equal")  # Equal aspect ratio ensures that pie is drawn as a circle.
    
    plt.show()
    

![image](http://matplotlib.org/mpl_examples/pie_and_polar_charts/pie_demo_features.png)

* * *

    #通过两个饼图绘制双层饼图
    import matplotlib.pyplot as plt
    
    vals1 = [1]
    vals2 = [1, 1, 2]
    vals3 = [1]
    vals4 = [1]
    
    fig, ax = plt.subplots()
    labels = 'A', 'B', 'C', 'D'
    
    ax.pie(vals1, radius=1.2)
    ax.pie(vals2, radius=1.0,startangle=90)
    ax.pie(vals3, radius=0.8)
    ax.pie(vals4, radius=0.4)
    ax.set(aspect="equal")
    plt.show()
    

![image](http://hysyeah.top/wp-content/uploads/2017/11/QQ图片20171127185444.png)

* * *

参考： 1.[https://zhuanlan.zhihu.com/p/27442584](https://zhuanlan.zhihu.com/p/27442584) 2.[http://matplotlib.org/api/pyplot_api.html](http://matplotlib.org/api/pyplot_api.html)